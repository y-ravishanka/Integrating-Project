﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AdminView
{
    public partial class AdminReportBuySell : Form
    {
        Message msg = new Message();

        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-1G3ODQ5;Initial Catalog=ayukarma;Integrated Security=True");
        private int i = 0, j = 0;

        public AdminReportBuySell()
        {
            InitializeComponent();
            loadData();
            activeChart();
        }

        #region Load Data Section
        private void loadDataChart(int t)
        {
            string que = null;
            chart1.Series.Clear();

            if (t == 1)
            {
                chart1.Series.Add("Total Sell");
                chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                que = "select date,(sum(webselling)+sum(desktopselling)) as total from systemusage";
            }
            else if (t == 2)
            {
                chart1.Series.Add("Web");
                chart1.Series.Add("Desktop");
                chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                chart1.Series[1].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                que = "select date,webselling,desktopselling from systemusage";
            }
            else if (t == 3)
            {
                chart1.Series.Add("Web");
                chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                que = "select date,webselling from systemusage";
            }
            else if (t == 4)
            {
                chart1.Series.Add("Desktop");
                chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                que = "select date,desktopselling from systemusage";
            }
            else if (t == 5)
            {
                chart1.Series.Add("Total Buy");
                chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                que = "select date,(sum(websbuying)+sum(desktopbuying)) as total from systemusage";
            }
            else if (t == 6)
            {
                chart1.Series.Add("Web");
                chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                que = "select date,websbuying from systemusage";
            }
            else if (t == 7)
            {
                chart1.Series.Add("Desktop");
                chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                que = "select date,desktopbuying from systemusage";
            }
            else if (t == 8)
            {
                chart1.Series.Add("Web");
                chart1.Series.Add("Desktop");
                chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                chart1.Series[1].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                que = "select date,websbuying,desktopbuying from systemusage";
            }
            else if (t == 9)
            {
                chart1.Series.Add("Web");
                chart1.Series.Add("Desktop");
                chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                chart1.Series[1].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                que = "select date,webspecialordres,desktopspecialordres from systemusage";
            }

            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        if (t == 1)
                        {
                            chart1.Series["Total Sell"].Points.AddXY(dr1.GetString(0), dr1.GetInt32(1));
                        }
                        else if (t == 2 || t == 8 || t == 9)
                        {
                            chart1.Series["Web"].Points.AddXY(dr1.GetString(0), dr1.GetInt32(1));
                            chart1.Series["Desktop"].Points.AddXY(dr1.GetString(0), dr1.GetInt32(2));
                        }
                        else if (t == 3 || t == 6)
                        {
                            chart1.Series["Web"].Points.AddXY(dr1.GetString(0), dr1.GetInt32(1));
                        }
                        else if (t == 4 || t == 7)
                        {
                            chart1.Series["Desktop"].Points.AddXY(dr1.GetString(0), dr1.GetInt32(1));
                        }
                        else if (t == 5)
                        {
                            chart1.Series["Total Buy"].Points.AddXY(dr1.GetString(0), dr1.GetInt32(1));
                        }
                    }
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                DialogResult d;
                d = MessageBox.Show("Invild Entry !!!\nPlease check your Entered Data\n" + s, "Error !!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (d == DialogResult.OK)
                {
                }
            }
            finally
            {
                con.Close();
            }
        }

        private void loadData()
        {
            string que = "select top 1 webselling,websbuying,desktopselling,desktopbuying,webspecialordres,desktopspecialordres from systemusage";
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        int t = dr1.GetInt32(0);
                        int t1 = dr1.GetInt32(1);
                        int t2 = dr1.GetInt32(2);
                        int t3 = dr1.GetInt32(3);
                        int t4 = dr1.GetInt32(4);
                        int t5 = dr1.GetInt32(5);

                        lab1.Text = (t + t2).ToString();
                        lab2.Text = (t).ToString();
                        lab3.Text = (t2).ToString();
                        lab4.Text = (t1 + t3).ToString();
                        lab5.Text = (t1).ToString();
                        lab6.Text = (t3).ToString();
                        lab7.Text = (t4).ToString();
                        lab8.Text = (t5).ToString();
                    }
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
        }
        #endregion

        #region Function Section
        private void butColor(Button bt)
        {
            Button[] but = { but1, but2, but3, but4, but5, but6, but7, but8, but9 };
            Panel[] pan = { pan1, pan2, pan3, pan4, pan5, pan6, pan7, pan8, pan9 };
            for (i = 0; i < but.Length; ++i)
            {
                pan[i].BackColor = Color.Gray;
                but[i].BackColor = Color.White;
                if (bt == but[i])
                {
                    pan[i].BackColor = Color.White;
                }
            }
        }

        private void activeChart()
        {
            butColor(but1);
            loadDataChart(1);
            txt.Text = "Total Sell";
        }
        #endregion

        private void but2_Click(object sender, EventArgs e)
        {
            butColor(but2);
            loadDataChart(2);
            txt.Text = "Total Web and Desktop Sell";
        }

        private void but3_Click(object sender, EventArgs e)
        {
            butColor(but3);
            loadDataChart(3);
            txt.Text = "Total Web Sell";
        }

        private void but4_Click(object sender, EventArgs e)
        {
            butColor(but4);
            loadDataChart(4);
            txt.Text = "Total Desktop Sell";
        }

        private void but7_Click(object sender, EventArgs e)
        {
            butColor(but5);
            loadDataChart(5);
            txt.Text = "Total Buy";
        }

        private void but6_Click(object sender, EventArgs e)
        {
            butColor(but6);
            loadDataChart(6);
            txt.Text = "Total Web Buy";
        }

        private void but5_Click(object sender, EventArgs e)
        {
            butColor(but7);
            loadDataChart(7);
            txt.Text = "Total Desktop Buy";
        }

        private void but8_Click(object sender, EventArgs e)
        {
            butColor(but8);
            loadDataChart(8);
            txt.Text = "Total Web and Desktop Buy";
        }

        private void but9_Click(object sender, EventArgs e)
        {
            butColor(but9);
            loadDataChart(9);
            txt.Text = "Orders";
        }

        private void but1_Click(object sender, EventArgs e)
        {
            butColor(but1);
            loadDataChart(1);
            txt.Text = "Total Sell";
        }
    }
}
