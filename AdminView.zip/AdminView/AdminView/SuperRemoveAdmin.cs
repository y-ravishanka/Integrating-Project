﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AdminView
{
    public partial class SuperRemoveAdmin : Form
    {
        SQLClass sql = new SQLClass();
        Message msg = new Message();
        Calculations cal = new Calculations();

        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-1G3ODQ5;Initial Catalog=ayukarma;Integrated Security=True");

        public SuperRemoveAdmin()
        {
            InitializeComponent();
            loadData();
            _ = sql.clearSelectAdminTable();
        }


        #region Load Data Section
        private void loadSelectData()
        {
            string que = "select nicno as NIC_No from selectedData";
            string table = "selectedData";
            try
            {
                SqlDataAdapter dta = new SqlDataAdapter(que, con);
                DataSet ds = new DataSet();
                dta.Fill(ds, table);
                selectAdminData.DataSource = ds;
                selectAdminData.DataMember = table;
            }
            catch (Exception e)
            {
                string x = Convert.ToString(e);
                msg.invalid_data(x);
            }
            finally
            {
                con.Close();
            }
        }

        private void loadRegisterAdminData()
        {
            string que = "select nicno as NIC_No, fname as First_Name,lname as Last_Name from admins";
            string table = "admins";
            try
            {
                SqlDataAdapter dta = new SqlDataAdapter(que, con);
                DataSet ds = new DataSet();
                dta.Fill(ds, table);
                registerAdminData.DataSource = ds;
                registerAdminData.DataMember = table;
            }
            catch (Exception e)
            {
                string x = Convert.ToString(e);
                msg.invalid_data(x);
            }
            finally
            {
                con.Close();
            }
        }

        private void loadRemovedAdminData()
        {
            string que = "select nicno as NIC_No, fname as First_Name,lname as Last_Name from adminhistory";
            string table = "adminhistory";
            try
            {
                SqlDataAdapter dta = new SqlDataAdapter(que, con);
                DataSet ds = new DataSet();
                dta.Fill(ds, table);
                deletedAdminData.DataSource = ds;
                deletedAdminData.DataMember = table;
            }
            catch (Exception e)
            {
                string x = Convert.ToString(e);
                msg.invalid_data(x);
            }
            finally
            {
                con.Close();
            }
        }

        private void loadData()
        {
            loadRegisterAdminData();
            loadRemovedAdminData();
        }
        #endregion

        #region Cleaning Section
        private void clearWarning()
        {
            warningtxt.Text = null;
        }

        private void clearNIC()
        {
            nictxt.Text = null;
        }
        #endregion

        #region Function Section
        private void addAdminSelect()
        {
            string nic = nictxt.Text;
            Boolean t = cal.checkNIC(nic);
            clearWarning();
            if (t == true)
            {
                int tmp = sql.setSelectAdminTable(nic);
                if (tmp == 1)
                {
                    loadSelectData();
                    warningtxt.Text = "NIC - " + nic + " Added";
                }
                else
                {
                    warningtxt.Text = "* Something Went Wrong";
                }
            }
            else if (t == false)
            {
                warningtxt.Text = "* Invalid NIC";
            }
        }

        private void removeAdminSelect()
        {
            string nic = nictxt.Text;
            Boolean t = cal.checkNIC(nic);
            clearWarning();
            if (t == true)
            {
                int tmp = sql.deleteSelectAdminTable(nic);
                if (tmp == 1)
                {
                    loadSelectData();
                    warningtxt.Text = "NIC - " + nic + " Removed";
                }
                else
                {
                    warningtxt.Text = "* Something Went Wrong";
                }
            }
            else if (t == false)
            {
                warningtxt.Text = "* Invalid NIC";
            }
        }

        private void removeAdminTable()
        {
            clearNIC();
            clearWarning();
            int t = sql.deleteAdminTable();
            if (t == 1)
            {
                loadSelectData();
                loadData();
                warningtxt.Text = "* Admin Removed Successfull";
            }
            else
            {
                warningtxt.Text = "* Something Went Wrong";
            }
        }

        private void removeSelectData()
        {
            clearNIC();
            clearWarning();
            int t = sql.clearSelectAdminTable();
            if (t == 1)
            {
                loadData();
                loadSelectData();
                warningtxt.Text = "* Selected Admins Cleared";
            }
            else
            {
                warningtxt.Text = "* Something Went Wrong";
            }
        }
        #endregion

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            clearNIC();
            clearWarning();
        }

        private void gunaButton3_Click(object sender, EventArgs e)
        {
            addAdminSelect();
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            removeAdminSelect();
        }

        private void gunaButton5_Click(object sender, EventArgs e)
        {
            removeAdminTable();
        }

        private void gunaButton4_Click(object sender, EventArgs e)
        {
            removeSelectData();
        }
    }
}
