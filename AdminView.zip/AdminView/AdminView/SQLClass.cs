﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AdminView
{
    class SQLClass
    {
        private int i, j;
        Message msg = new Message();
        Calculations cal = new Calculations();

        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-1G3ODQ5;Initial Catalog=ayukarma;Integrated Security=True");

        // Insert, Update, Delete query execute structure
        public int setFunctionName(/* parameters you need */)
        {
            int tmp = 0;
            string que = "query String you want"; // query 
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open(); // con open
                cmd.ExecuteNonQuery(); // query execute
                tmp = 1; // query sucessful, send 1 to program to identify query success
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e); // convet exception to String
                tmp = 0; msg.invalid_data(s); // query failed, send 0 to program to identify query fail, and show the exception error
            }
            finally
            {
                con.Close(); // con close
            }
            return tmp; // send to program query success or fail
        }

        // Select query execute structure
        public string[] getFunctionName(/* parameters you need */)
        {
            string[] tmp = null; // store query extracted data
            int t = 0; // store query success or fail
            string que = "query String you want"; // query 
            SqlCommand cmd1 = new SqlCommand(que, con); // sql command
            try
            {
                con.Open(); // con open
                SqlDataReader dr1 = cmd1.ExecuteReader(); // open a reader and execute
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        tmp[1] = dr1.GetString(0); // get what you want to get
                    }
                    t = 1; // has data and query successfull
                }
                dr1.Close(); // close reader
            }
            catch (Exception e)
            {
                t = 0; // query failed
                string s = Convert.ToString(e); // convet exception to String
                msg.invalid_data(s); // exception message show exception error
            }
            finally
            {
                con.Close(); // con close
            }
            tmp[0] = t.ToString(); // success or fail convet to string and inclued to String array that return
            return tmp; // return data
        }

        #region LogIn Functions Section
        public string[] check_Login(String uname)
        {
            string[] tmp = new string[2];
            string s1 = "";
            int t = 0;
            string que = "select Password from admindetails where NICNo = '"+uname+"'";
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        s1 = dr1.GetString(0);
                    }
                    t = 1;
                }
                dr1.Close();
                tmp[0] = t.ToString();
                tmp[1] = s1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public int checkAdminNew(String uname)
        {
            int t = 2;
            string que = "select temp from admindetails where NICNo = '" + uname + "'";
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        t = dr1.GetInt32(0);
                    }
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return t;
        }

        public int getPosition(String s)
        {
            string tmp = null;
            int t = 0, p = 0;
            string que = "select position from admindetails where nicno = '"+s+"'";
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        tmp = dr1.GetString(0);
                    }
                    t = 1;
                }
                dr1.Close();
                if (t == 1)
                {
                    if (tmp == "super")
                    { p = 2; }
                    else if (tmp == "normal")
                    { p = 1; }
                }
            }
            catch (Exception e)
            {
                t = 0;
                string x = Convert.ToString(e);
                msg.invalid_data(x);
            }
            finally
            {
                con.Close();
            }
            return p;
        }
        #endregion

        #region Super Admin Functions Section
        public string[] getSuperUpdateAdminData(string nic)
        {
            string[] tmp = new string[5];
            int t = 0;
            string que = "select fname,mname,lname from admins where nicno = '"+nic+"'";
            string que1 = "select position from admindetails where nicno = '"+nic+"'";
            SqlCommand cmd1 = new SqlCommand(que, con);
            SqlCommand cmd2 = new SqlCommand(que1, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        tmp[1] = dr1.GetString(0);
                        tmp[2] = dr1.GetString(1);
                        tmp[3] = dr1.GetString(2);
                    }
                    t = 1;
                }
                dr1.Close();
                if (t == 1)
                {
                    con.Open();
                    SqlDataReader dr2 = cmd2.ExecuteReader();
                    if (dr2.HasRows)
                    {
                        while (dr2.Read())
                        {
                            tmp[4] = dr2.GetString(0);
                        }
                        t = 1;
                    }
                    dr2.Close();
                }
            }
            catch (Exception e)
            {
                t = 0;
                string s = Convert.ToString(e);
                msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            tmp[0] = t.ToString();
            return tmp;
        }

        public int setSuperUpdateAdminPosition(string nic, string position)
        {
            int tmp = 0;
            string que = "update admindetails set position = '"+position+"' where nicno = '"+nic+"'";
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0; msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public int setSelectAdminTable(string nic) 
        {
            int tmp = 0;
            string que = "insert into nicno values ('"+nic+"')";
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0; msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public int deleteSelectAdminTable(string nic) 
        {
            int tmp = 0;
            string que = "delete from seleteddata where nicno = '"+nic+"'";
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0; msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public int addAdminTable() 
        {
            int tmp = 0;
            string que = "insert into admindetails(nicno) (select nicno from selecteddata)";
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0; msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public int deleteAdminTable()
        {
            int tmp = 0;
            string que = "delete from admins where admins.nicno in (select selecteddata.nicno from selecteddata)";
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0; msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public int clearSelectAdminTable() 
        {
            int tmp = 0;
            string que = "delete seleteddata";
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0; msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public string[] getAdminDetails(string nic) 
        {
            string[] tmp = new string[9];
            int t = 0;
            tmp[0] = t.ToString();
            string que = "select fname,mname,lname,dob,aadline1,aadline2,aadline3,email from admins where nicno = '"+nic+"'";
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        tmp[1] = dr1.GetString(0);
                        tmp[2] = dr1.GetString(1);
                        tmp[3] = dr1.GetString(2);
                        tmp[4] = dr1.GetDateTime(3).ToString();
                        tmp[5] = dr1.GetString(4);
                        tmp[6] = dr1.GetString(5);
                        tmp[7] = dr1.GetString(6);
                        tmp[8] = dr1.GetString(7);
                    }
                    t = 1;
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                t = 0;
                string s = Convert.ToString(e);
                msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            tmp[0] = t.ToString();
            return tmp;
        }

        public string[] getAdminEmail(string nic)
        {
            string[] tmp = new string[2];
            int t = 0;
            string que = "select email from admins where nicno = '" + nic + "'";
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        tmp[1] = dr1.GetString(0);
                    }
                    t = 1;
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                t = 0;
                string s = Convert.ToString(e);
                msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            tmp[0] = t.ToString();
            return tmp;
        }
        #endregion

        public string getAdminNumber()//------------------------------------------
        {
            string tmp = null;
            int t = 0;
            string que = "select ";
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        tmp = dr1.GetString(0);
                    }
                    t = 1;
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                t = 0;
                string s = Convert.ToString(e);
                msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        #region System Email Functions Section
        public string[] getSystemEmail()//----------------------------------------------------
        {
            string[] tmp = new string[2];
            int t = 0;
            string que = "";
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        tmp[0] = dr1.GetString(0);
                        tmp[1] = dr1.GetString(1);
                    }
                    t = 1;
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                t = 0;
                string s = Convert.ToString(e);
                msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public string getSystemEmailPassword(string email)
        {
            string tmp = null;
            int t = 0;
            string que = "select password from systemdetails where email = '"+email+"'";
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        tmp = dr1.GetString(0);
                    }
                    t = 1;
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                t = 0;
                string s = Convert.ToString(e);
                msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }
        #endregion

        #region Change Password Functions Section
        public int updateAdminPasswords(string uname, string pword)
        {
            int tmp = 0;
            string que = "update admindetails set password = '" + pword + "' where nicno = '" + uname + "'";
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0; msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public int setAdminPasswords(string uname, string pword)
        {
            int tmp = 0;
            string que = "update admindetails set password = '" + pword + "' where nicno = '" + uname + "'";
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0; msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public string checkAdminPassword(string s1) 
        {
            string t = null;
            string que = "select password from admindetails where NICNo = '" + s1 + "'";
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        t = dr1.GetString(0);
                    }
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return t;
        }
        #endregion

        public string[] getUserData(int t1, string s1)
        {
            string[] tmp = new string[12];
            int t = 0;
            string que = null;
            if(t1 == 1)
            {
                que = "select nicno,fname,mname,lname,uadline1,uadline2,uadline3,gender,telephone,email from users where nicno = '" + s1 + "'";
            }
            else if(t1 == 2)
            {
                int tmp1 = int.Parse(s1);
                que = "select nicno,fname,mname,lname,uadline1,uadline2,uadline3,gender,telephone,email,userid from users where userid = " + tmp1;
            }
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        tmp[1] = dr1.GetString(0);
                        tmp[2] = dr1.GetString(1);
                        tmp[3] = dr1.GetString(2);
                        tmp[4] = dr1.GetString(3);
                        tmp[5] = dr1.GetString(4);
                        tmp[6] = dr1.GetString(5);
                        tmp[7] = dr1.GetString(6);
                        tmp[8] = dr1.GetString(7);
                        tmp[9] = dr1.GetInt64(8).ToString();
                        tmp[10] = dr1.GetString(9);
                        tmp[11] = dr1.GetInt32(10).ToString();
                    }
                    t = 1;
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                t = 0;
                string s = Convert.ToString(e);
                msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            tmp[0] = t.ToString();
            return tmp;
        }

        public int deleteUser(int t, string s1)
        {
            int tmp = 0;
            string que = null;
            if(t == 1)
            {
                que = "delete from users where nicno = '" + s1 + "'";
            }
            else if(t == 2)
            {
                que = "delete from users where userid = " + s1;
            }
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0; msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public int[] getSellid()
        {
            int[] tmp = new int[1000];
            int t = 0;
            string que = "select sellingid from selling";
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();

                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        tmp[t] = dr1.GetInt32(0);
                        t++;
                        if(t == 1000)
                        {
                            break;
                        }
                    }
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public string[] getSellData(int id)
        {
            string[] tmp = new string[13];
            int t = 0;
            string que = "select userid,item,category,price,quantity,unit,address,telephone,imagename1,imagename2,imagename3,imagename4,imagename5 from selling where sellingid = "+id;
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        tmp[0] = dr1.GetInt32(0).ToString();
                        tmp[1] = dr1.GetString(1);
                        tmp[2] = dr1.GetString(2);
                        tmp[3] = dr1.GetFloat(3).ToString();
                        tmp[4] = dr1.GetString(4);
                        tmp[5] = dr1.GetString(5);
                        tmp[6] = dr1.GetString(6);
                        tmp[7] = dr1.GetInt64(7).ToString();
                        tmp[8] = dr1.GetString(8);
                        tmp[9] = dr1.GetString(9);
                        tmp[10] = dr1.GetString(10);
                        tmp[11] = dr1.GetString(11);
                        tmp[12] = dr1.GetString(12);
                    }
                    t = 1;
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                t = 0;
                string s = Convert.ToString(e);
                msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public int setProducts(string name,string description,float price,string imagename,string category,string tags)
        {
            int tmp = 0;
            string que = "insert into products(name,description,price,imagename,category,tags) values('"+name+"','"+description + "','" + price + "','" + imagename + "','" + category + "','" + tags + "')";
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0; msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public int setMaterial(string name, string description, float price, string imagename, string category, string tags)
        {
            int tmp = 0;
            string que = "insert into rawmaterials(name,description,price,imagename,category,tags) values('" + name + "','" + description + "','" + price + "','" + imagename + "','" + category + "','" + tags + "')";
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0; msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public int deleteSell(int id)
        {
            int tmp = 0;
            string que = "delete selling where sellingid = "+id;
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0; msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public int[] getAdminID()
        {
            string[] s1 = new string[100000];
            int t = 0;
            string que = "select adminid from admins";
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        s1[t] = dr1.GetString(0);
                        t++;
                    }
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            int[] tmp = new int[s1.Length];
            for(i=0;i<s1.Length;++i)
            {
                tmp[i] = cal.getAdminIntId(s1[i]);
            }
            return tmp;
        }

        #region Admin Register Functions Section
        public int insertAdmin(string fname, string mname, string lname, string nicno, DateTime dob, string aadline1, string aadline2, string aadline3, string email)
        {
            int tmp = 0;
            string que = "insert into admins(fname,mname,lname,nicno,dob,aadline1,aadline2,aadline3,email) values ('" + fname + "','" + mname + "','" + lname + "','" + nicno + "','" + dob + "','" + aadline1 + "','" + aadline2 + "','" + aadline3 + "','" + email + "')";
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0; msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public int setAdminPassword(string uname, string pword)
        {
            int tmp = 0;
            string que = "update admindetails set password = '" + pword + "', position = 'normal' where nicno = '" + uname + "'";
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0; msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }
        
        public int setAdminNew(string uname, string pword)
        {
            int tmp = 0;
            string que = "update admindetails set temp = 1 where nicno = '" + uname + "'";
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0; msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        #endregion

        #region Center Functions Section
        public int insertCenter(string cenname, int phone, string email, string descrip, string imagename, decimal lat, decimal lng)
        {
            int tmp = 0;
            string que = "insert into centre(cenname,phone,email,descrip,imagename,lat,lng) values ('" + cenname + "'," + phone + ",'" + email + "','" + descrip + "','" + imagename + "'," + lat + "," + lng + ")";
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0; msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        #endregion

        #region Doctor Functions Section
        public int insertDoctor(string docname, int phone, string email, string descrip, string imagename, decimal lat, decimal lng)
        {
            int tmp = 0;
            string que = "insert into doctor(docname,phone,email,descrip,imagename,lat,lng) values ('" + docname + "'," + phone + ",'" + email + "','" + descrip + "','" + imagename + "'," + lat + "," + lng + ")";
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0; msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public string[] getDoctorDetails(string name)
        {
            string[] tmp = new string[9];
            int t = 0;
            tmp[0] = t.ToString();
            string que = "select * from doctor where docname = '" + name + "'";
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        tmp[1] = dr1.GetInt32(0).ToString();
                        tmp[2] = dr1.GetString(1);
                        tmp[3] = dr1.GetInt32(2).ToString();
                        tmp[4] = dr1.GetString(3);
                        tmp[5] = dr1.GetString(4);
                        tmp[6] = dr1.GetString(5);
                        tmp[7] = dr1.GetDecimal(6).ToString();
                        tmp[8] = dr1.GetDecimal(7).ToString();
                    }
                    t = 1;
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                t = 0;
                string s = Convert.ToString(e);
                msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            tmp[0] = t.ToString();
            return tmp;
        }

        public int hasDoctor(string name)
        {
            int t = 0;
            string que = "select id from doctor where docname = '" + name + "'";
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    t = 1;
                }
                else
                {
                    t = 0;
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                t = 0;
                string s = Convert.ToString(e);
                msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            return t;
        }
        #endregion

        #region System Data Section
        public string[] getSystemData(string date)
        {
            string[] tmp = new string[9];
            int t = 0;
            tmp[0] = t.ToString();
            string que = "select weblogin,desktoplogin,webselling,desktopselling,websbuying,desktopbuying,WebSpecialorders,DesktopSpecialorders from systemusage where date = '" + date + "'";
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        tmp[1] = dr1.GetString(0).ToString();
                        tmp[2] = dr1.GetString(1).ToString();
                        tmp[3] = dr1.GetString(2).ToString();
                        tmp[4] = dr1.GetString(3).ToString();
                        tmp[5] = dr1.GetString(4).ToString();
                        tmp[6] = dr1.GetString(5).ToString();
                        tmp[7] = dr1.GetString(6).ToString();
                        tmp[8] = dr1.GetString(7).ToString();
                    }
                    t = 1;
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                t = 0;
                string s = Convert.ToString(e);
                msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
            tmp[0] = t.ToString();
            return tmp;
        }
        #endregion

        public int test1()
        {
            int tmp = 0;
            string que = ""; 
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery(); 
                tmp = 1; 
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e); 
                tmp = 0; msg.invalid_data(s); 
            }
            finally
            {
                con.Close(); 
            }
            return tmp; 
        }

        public string[] test2()
        {
            string[] tmp = null;
            int t = 0; 
            string que = "";
            SqlCommand cmd1 = new SqlCommand(que, con); 
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        tmp[1] = dr1.GetString(0); 
                    }
                    t = 1; 
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                t = 0; 
                string s = Convert.ToString(e); 
                msg.invalid_data(s); 
            }
            finally
            {
                con.Close(); 
            }
            tmp[0] = t.ToString(); 
            return tmp; 
        }
    }
}
