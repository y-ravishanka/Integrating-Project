﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AdminView
{
    public partial class AdminDeleteEOrder : Form
    {
        SQLClass sql = new SQLClass();
        Message msg = new Message();

        private int i = 0, j = 0;
        private SqlConnection con = new SqlConnection(@"");

        public AdminDeleteEOrder()
        {
            InitializeComponent();
        }

        #region Color Customize Section
        private void butColorNull()
        {
            Panel[] pan1 = { panelOrders, panelDOrders };
            Button[] but1 = { butOrders, butDOrders };
            for (i = 0; i < pan1.Length; ++i)
            {
                pan1[i].BackColor = Color.Gray;
                but1[i].BackColor = Color.White;
            }
        }

        private void butColor(Button but)
        {
            butColorNull();
            Panel[] pan1 = { panelOrders, panelDOrders };
            Button[] but1 = { butOrders, butDOrders };
            for (i = 0; i < but1.Length; ++i)
            {
                if (but == but1[i])
                {
                    //pan1[i].BackColor = Color.FromArgb(100, 88, 255);
                    pan1[i].BackColor = Color.White;
                }
            }
        }
        #endregion

        #region Load Data Section
        private void loadData(int t)
        {
            string table = null;
            string que = null;

            if(t == 1)
            {
                table = "";
                que = "";
            }
            else if(t == 2)
            {
                table = "";
                que = "";
            }

            try
            {
                SqlDataAdapter dta = new SqlDataAdapter(que, con);
                DataSet ds = new DataSet();
                dta.Fill(ds, table);
                dataView.DataSource = ds;
                dataView.DataMember = table;
                table = null;
            }
            catch (Exception e)
            {
                string s1 = Convert.ToString(e);
                msg.invalid_data(s1);
            }
            finally
            {
                con.Close();
            }
        }
        #endregion

        #region Function Section
        private void clickDOrder()
        {
            butColor(butDOrders);
            loadData(2);
        }

        private void clickOrder()
        {
            butColor(butOrders);
            loadData(1);
        }
        #endregion

        private void butDOrders_Click(object sender, EventArgs e)
        {
            clickDOrder();
        }

        private void butOrders_Click(object sender, EventArgs e)
        {
            clickOrder();
        }

    }
}
