﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdminView
{
    public partial class Profile : Form
    {
        private Form activeForm = null;
        private string nic = null;

        SQLClass sql = new SQLClass();

        public Profile(string nic)
        {
            InitializeComponent();
            this.nic = nic;
            //openFroms(new Profile2(nic));
        }
        /*
        private void openFroms(Form childForm)
        {
            if (activeForm != null)
            {
                activeForm.Close(); // clear-up the varible to store childForm
            }
            activeForm = childForm; // save childForm in activeForm varible
            childForm.TopLevel = false; // stop childForm from behaving like a controler
            childForm.FormBorderStyle = FormBorderStyle.None; // remove childForm borders
            childForm.Dock = DockStyle.Fill; // make childForm fill the entire space
            panelBase.Controls.Add(childForm);
            panelBase.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }*/

        private void setAdmin()
        {
            _ = sql.insertAdmin(txt1.Text, txt2.Text, txt3.Text, nic, txt4.Value, txt5.Text, txt6.Text, txt7.Text, txt8.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            setAdmin();
            FormArrange.loginPage.Show();
            this.Close();
        }
    }
}
