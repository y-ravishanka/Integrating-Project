﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdminView
{
    public class FormArrange
    {
        public static ResetPassword resetPassword
        {
            get
            {
                if (rePass == null)
                {
                    rePass = new ResetPassword();
                }
                return rePass;
            }
        }
        private static ResetPassword rePass;
        
        public static LoginPage loginPage
        {
            get
            {
                if (lpage == null)
                {
                    lpage = new LoginPage();
                }
                return lpage;
            }
        }
        private static LoginPage lpage;
    }
}
