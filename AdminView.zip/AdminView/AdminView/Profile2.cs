﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdminView
{
    public partial class Profile2 : Form
    {
        SQLClass sql = new SQLClass();
        EncryptClass ent = new EncryptClass();

        private string nic = null;

        public Profile2(string nic)
        {
            InitializeComponent();
            this.nic = nic;
            clear();
        }

        #region Function Section
        private void clear()
        {
            warning2.Text = null;
            warning1.Text = null;
        }

        private void setpassword()
        {
            clear();
            string np = txt1.Text;
            string np1 = txt2.Text;
            if(np == null || np == "")
            {
                warning1.Text = "* Enter a Password";
            }
            else if(np1 == null || np1 == "")
            {
                warning2.Text = "* Enter a Comform Password";
            }
            else if(np != np1)
            {
                warning1.Text = "* Password doesn't match";
            }
            else
            {
                int tmp = sql.setAdminPassword(nic, ent.Encrypt(np, nic));
                if(tmp == 1)
                {
                    this.Close();
                    FormArrange.loginPage.Show();
                }
            }
        }
        #endregion

        private void button1_Click(object sender, EventArgs e)
        {
            setpassword();
        }

        #region TextBox Settings Section
        private void txt1_Enter(object sender, EventArgs e)
        {
            if (txt1.Text == "Password")
            {
                txt1.Text = "";
                txt1.ForeColor = Color.Black;
                txt1.PasswordChar = '*';
                pan1.BackColor = Color.FromArgb(76, 175, 80);
            }
        }

        private void txt1_Leave(object sender, EventArgs e)
        {
            if (txt1.Text == "")
            {
                txt1.Text = "Password";
                txt1.PasswordChar = '\0';
                txt1.ForeColor = Color.Gray;
                pan1.BackColor = Color.Gray;
            }
        }

        private void txt2_Enter(object sender, EventArgs e)
        {
            if (txt2.Text == "Conform Password")
            {
                txt2.Text = "";
                txt2.ForeColor = Color.Black;
                txt2.PasswordChar = '*';
                pan2.BackColor = Color.FromArgb(76, 175, 80);
            }
        }

        private void txt2_Leave(object sender, EventArgs e)
        {
            if (txt2.Text == "")
            {
                txt2.Text = "Conform Password";
                txt2.PasswordChar = '\0';
                txt2.ForeColor = Color.Gray;
                pan2.BackColor = Color.Gray;
            }
        }
        #endregion
    }
}
