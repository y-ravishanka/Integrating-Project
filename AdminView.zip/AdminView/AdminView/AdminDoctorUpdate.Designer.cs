﻿
namespace AdminView
{
    partial class AdminDoctorUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gunaVSeparator1 = new Guna.UI.WinForms.GunaVSeparator();
            this.warning = new System.Windows.Forms.Label();
            this.gunaButton1 = new Guna.UI.WinForms.GunaButton();
            this.tx1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lab5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lab8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lab6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lab4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lab7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lab3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lab2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lab1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panelUpdate = new System.Windows.Forms.Panel();
            this.combo = new System.Windows.Forms.ComboBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.gunaButton2 = new Guna.UI.WinForms.GunaButton();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panelUpdate.SuspendLayout();
            this.SuspendLayout();
            // 
            // gunaVSeparator1
            // 
            this.gunaVSeparator1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.gunaVSeparator1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gunaVSeparator1.LineColor = System.Drawing.Color.Silver;
            this.gunaVSeparator1.Location = new System.Drawing.Point(45, 12);
            this.gunaVSeparator1.Name = "gunaVSeparator1";
            this.gunaVSeparator1.Size = new System.Drawing.Size(15, 409);
            this.gunaVSeparator1.TabIndex = 0;
            // 
            // warning
            // 
            this.warning.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.warning.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warning.ForeColor = System.Drawing.Color.Red;
            this.warning.Location = new System.Drawing.Point(549, 47);
            this.warning.Name = "warning";
            this.warning.Size = new System.Drawing.Size(325, 33);
            this.warning.TabIndex = 34;
            this.warning.Text = "* warning";
            this.warning.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // gunaButton1
            // 
            this.gunaButton1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton1.AnimationHoverSpeed = 0.07F;
            this.gunaButton1.AnimationSpeed = 0.03F;
            this.gunaButton1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton1.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.gunaButton1.ForeColor = System.Drawing.Color.White;
            this.gunaButton1.Image = null;
            this.gunaButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton1.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton1.Location = new System.Drawing.Point(880, 12);
            this.gunaButton1.Name = "gunaButton1";
            this.gunaButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton1.OnHoverImage = null;
            this.gunaButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton1.Size = new System.Drawing.Size(160, 32);
            this.gunaButton1.TabIndex = 32;
            this.gunaButton1.Text = "Search";
            this.gunaButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton1.Click += new System.EventHandler(this.gunaButton1_Click);
            // 
            // tx1
            // 
            this.tx1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tx1.BackColor = System.Drawing.SystemColors.MenuBar;
            this.tx1.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx1.ForeColor = System.Drawing.Color.Gray;
            this.tx1.Location = new System.Drawing.Point(549, 12);
            this.tx1.Name = "tx1";
            this.tx1.Size = new System.Drawing.Size(325, 32);
            this.tx1.TabIndex = 25;
            this.tx1.Text = "Search by Name";
            this.tx1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(66, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(185, 30);
            this.label1.TabIndex = 17;
            this.label1.Text = "Update a Doctor";
            // 
            // lab5
            // 
            this.lab5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab5.Location = new System.Drawing.Point(666, 97);
            this.lab5.Name = "lab5";
            this.lab5.Size = new System.Drawing.Size(342, 108);
            this.lab5.TabIndex = 43;
            this.lab5.Text = "Description ";
            this.lab5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(533, 97);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(127, 27);
            this.label9.TabIndex = 44;
            this.label9.Text = "Description :";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab8
            // 
            this.lab8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab8.Location = new System.Drawing.Point(200, 271);
            this.lab8.Name = "lab8";
            this.lab8.Size = new System.Drawing.Size(264, 27);
            this.lab8.TabIndex = 45;
            this.lab8.Text = "Lng ";
            this.lab8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(67, 271);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(127, 27);
            this.label7.TabIndex = 46;
            this.label7.Text = "Lng :";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab6
            // 
            this.lab6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab6.Location = new System.Drawing.Point(666, 232);
            this.lab6.Name = "lab6";
            this.lab6.Size = new System.Drawing.Size(342, 27);
            this.lab6.TabIndex = 35;
            this.lab6.Text = "ImageName ";
            this.lab6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(533, 232);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(127, 27);
            this.label8.TabIndex = 36;
            this.label8.Text = "ImageName :";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab4
            // 
            this.lab4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab4.Location = new System.Drawing.Point(200, 195);
            this.lab4.Name = "lab4";
            this.lab4.Size = new System.Drawing.Size(264, 27);
            this.lab4.TabIndex = 47;
            this.lab4.Text = "Email ";
            this.lab4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(67, 195);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(127, 27);
            this.label5.TabIndex = 48;
            this.label5.Text = "Email :";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab7
            // 
            this.lab7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab7.Location = new System.Drawing.Point(200, 231);
            this.lab7.Name = "lab7";
            this.lab7.Size = new System.Drawing.Size(264, 27);
            this.lab7.TabIndex = 37;
            this.lab7.Text = "Lat ";
            this.lab7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(67, 231);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(127, 27);
            this.label6.TabIndex = 38;
            this.label6.Text = "Lat :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab3
            // 
            this.lab3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab3.Location = new System.Drawing.Point(200, 158);
            this.lab3.Name = "lab3";
            this.lab3.Size = new System.Drawing.Size(264, 27);
            this.lab3.TabIndex = 39;
            this.lab3.Text = "Phone ";
            this.lab3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(67, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 27);
            this.label4.TabIndex = 40;
            this.label4.Text = "Phone :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab2
            // 
            this.lab2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab2.Location = new System.Drawing.Point(200, 121);
            this.lab2.Name = "lab2";
            this.lab2.Size = new System.Drawing.Size(264, 27);
            this.lab2.TabIndex = 49;
            this.lab2.Text = "Name ";
            this.lab2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(67, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 27);
            this.label3.TabIndex = 50;
            this.label3.Text = "Name :";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab1
            // 
            this.lab1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab1.Location = new System.Drawing.Point(200, 85);
            this.lab1.Name = "lab1";
            this.lab1.Size = new System.Drawing.Size(264, 27);
            this.lab1.TabIndex = 41;
            this.lab1.Text = "Doctor ID ";
            this.lab1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(67, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 27);
            this.label2.TabIndex = 42;
            this.label2.Text = "Doctor ID :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panelUpdate
            // 
            this.panelUpdate.Controls.Add(this.combo);
            this.panelUpdate.Controls.Add(this.txt2);
            this.panelUpdate.Controls.Add(this.gunaButton2);
            this.panelUpdate.Controls.Add(this.label10);
            this.panelUpdate.Controls.Add(this.label11);
            this.panelUpdate.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelUpdate.Location = new System.Drawing.Point(0, 323);
            this.panelUpdate.Name = "panelUpdate";
            this.panelUpdate.Size = new System.Drawing.Size(1052, 110);
            this.panelUpdate.TabIndex = 51;
            // 
            // combo
            // 
            this.combo.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo.FormattingEnabled = true;
            this.combo.Items.AddRange(new object[] {
            "Doctor ID",
            "Name",
            "Phone",
            "Email",
            "Description",
            "Image Name",
            "Lat",
            "Lng"});
            this.combo.Location = new System.Drawing.Point(235, 18);
            this.combo.Name = "combo";
            this.combo.Size = new System.Drawing.Size(308, 33);
            this.combo.TabIndex = 55;
            this.combo.TextChanged += new System.EventHandler(this.comboBox1_TextChanged);
            // 
            // txt2
            // 
            this.txt2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt2.BackColor = System.Drawing.SystemColors.MenuBar;
            this.txt2.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt2.ForeColor = System.Drawing.Color.Gray;
            this.txt2.Location = new System.Drawing.Point(549, 18);
            this.txt2.Multiline = true;
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(325, 80);
            this.txt2.TabIndex = 54;
            this.txt2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // gunaButton2
            // 
            this.gunaButton2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButton2.AnimationHoverSpeed = 0.07F;
            this.gunaButton2.AnimationSpeed = 0.03F;
            this.gunaButton2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaButton2.BorderColor = System.Drawing.Color.Black;
            this.gunaButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton2.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton2.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.gunaButton2.ForeColor = System.Drawing.Color.White;
            this.gunaButton2.Image = null;
            this.gunaButton2.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton2.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton2.Location = new System.Drawing.Point(880, 18);
            this.gunaButton2.Name = "gunaButton2";
            this.gunaButton2.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton2.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton2.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton2.OnHoverImage = null;
            this.gunaButton2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton2.Size = new System.Drawing.Size(160, 33);
            this.gunaButton2.TabIndex = 53;
            this.gunaButton2.Text = "Update";
            this.gunaButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton2.Click += new System.EventHandler(this.gunaButton2_Click);
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(3, 2);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(226, 64);
            this.label10.TabIndex = 42;
            this.label10.Text = "Select the Field you want to update";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(235, 54);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(308, 33);
            this.label11.TabIndex = 34;
            this.label11.Text = "* warning";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // AdminDoctorUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1052, 433);
            this.Controls.Add(this.panelUpdate);
            this.Controls.Add(this.lab5);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lab8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lab6);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lab4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lab7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lab3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lab2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lab1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.warning);
            this.Controls.Add(this.gunaButton1);
            this.Controls.Add(this.tx1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gunaVSeparator1);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MinimumSize = new System.Drawing.Size(1068, 472);
            this.Name = "AdminDoctorUpdate";
            this.Text = "AdminDoctorUpdate";
            this.panelUpdate.ResumeLayout(false);
            this.panelUpdate.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI.WinForms.GunaVSeparator gunaVSeparator1;
        private System.Windows.Forms.Label warning;
        private Guna.UI.WinForms.GunaButton gunaButton1;
        private System.Windows.Forms.TextBox tx1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lab5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lab8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lab6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lab4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lab7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lab3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lab2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lab1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panelUpdate;
        private System.Windows.Forms.ComboBox combo;
        private System.Windows.Forms.TextBox txt2;
        private Guna.UI.WinForms.GunaButton gunaButton2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
    }
}