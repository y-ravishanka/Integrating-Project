﻿
namespace AdminView
{
    partial class AdminProfileEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gunaVSeparator1 = new Guna.UI.WinForms.GunaVSeparator();
            this.gunaButton1 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton3 = new Guna.UI.WinForms.GunaButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.warning1 = new System.Windows.Forms.Label();
            this.fname = new Guna.UI.WinForms.GunaTextBox();
            this.lname = new Guna.UI.WinForms.GunaTextBox();
            this.mname = new Guna.UI.WinForms.GunaTextBox();
            this.warning2 = new System.Windows.Forms.Label();
            this.addl1 = new Guna.UI.WinForms.GunaTextBox();
            this.addl2 = new Guna.UI.WinForms.GunaTextBox();
            this.addl3 = new Guna.UI.WinForms.GunaTextBox();
            this.warning3 = new System.Windows.Forms.Label();
            this.gunaButton4 = new Guna.UI.WinForms.GunaButton();
            this.warning6 = new System.Windows.Forms.Label();
            this.email = new Guna.UI.WinForms.GunaTextBox();
            this.dob = new Guna.UI.WinForms.GunaDateTimePicker();
            this.warning5 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // gunaVSeparator1
            // 
            this.gunaVSeparator1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.gunaVSeparator1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gunaVSeparator1.LineColor = System.Drawing.Color.Silver;
            this.gunaVSeparator1.Location = new System.Drawing.Point(109, 12);
            this.gunaVSeparator1.Name = "gunaVSeparator1";
            this.gunaVSeparator1.Size = new System.Drawing.Size(10, 498);
            this.gunaVSeparator1.TabIndex = 0;
            // 
            // gunaButton1
            // 
            this.gunaButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaButton1.AnimationHoverSpeed = 0.07F;
            this.gunaButton1.AnimationSpeed = 0.03F;
            this.gunaButton1.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton1.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.gunaButton1.ForeColor = System.Drawing.Color.White;
            this.gunaButton1.Image = null;
            this.gunaButton1.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton1.Location = new System.Drawing.Point(896, 468);
            this.gunaButton1.Name = "gunaButton1";
            this.gunaButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton1.OnHoverImage = null;
            this.gunaButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton1.Radius = 20;
            this.gunaButton1.Size = new System.Drawing.Size(160, 42);
            this.gunaButton1.TabIndex = 1;
            this.gunaButton1.Text = "Close";
            this.gunaButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton1.Click += new System.EventHandler(this.gunaButton1_Click);
            // 
            // gunaButton3
            // 
            this.gunaButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaButton3.AnimationHoverSpeed = 0.07F;
            this.gunaButton3.AnimationSpeed = 0.03F;
            this.gunaButton3.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton3.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaButton3.BorderColor = System.Drawing.Color.Black;
            this.gunaButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton3.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton3.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.gunaButton3.ForeColor = System.Drawing.Color.White;
            this.gunaButton3.Image = null;
            this.gunaButton3.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton3.Location = new System.Drawing.Point(730, 468);
            this.gunaButton3.Name = "gunaButton3";
            this.gunaButton3.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton3.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton3.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton3.OnHoverImage = null;
            this.gunaButton3.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton3.Radius = 20;
            this.gunaButton3.Size = new System.Drawing.Size(160, 42);
            this.gunaButton3.TabIndex = 1;
            this.gunaButton3.Text = "Save";
            this.gunaButton3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(148, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "First Name";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(568, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Last Name";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(148, 175);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Middle Name";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(148, 257);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Address";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(568, 339);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 20);
            this.label5.TabIndex = 2;
            this.label5.Text = "Email";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(568, 257);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 20);
            this.label7.TabIndex = 2;
            this.label7.Text = "Date of Birth";
            // 
            // warning1
            // 
            this.warning1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.warning1.AutoSize = true;
            this.warning1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warning1.ForeColor = System.Drawing.Color.Red;
            this.warning1.Location = new System.Drawing.Point(149, 149);
            this.warning1.Name = "warning1";
            this.warning1.Size = new System.Drawing.Size(75, 17);
            this.warning1.TabIndex = 2;
            this.warning1.Text = "* warning";
            // 
            // fname
            // 
            this.fname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.fname.BackColor = System.Drawing.Color.Transparent;
            this.fname.BaseColor = System.Drawing.Color.White;
            this.fname.BorderColor = System.Drawing.Color.Silver;
            this.fname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.fname.FocusedBaseColor = System.Drawing.Color.White;
            this.fname.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.fname.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.fname.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.fname.Location = new System.Drawing.Point(152, 116);
            this.fname.Name = "fname";
            this.fname.PasswordChar = '\0';
            this.fname.Radius = 14;
            this.fname.SelectedText = "";
            this.fname.Size = new System.Drawing.Size(237, 30);
            this.fname.TabIndex = 3;
            this.fname.Text = "gunaTextBox1";
            this.fname.TextOffsetX = 5;
            // 
            // lname
            // 
            this.lname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lname.BackColor = System.Drawing.Color.Transparent;
            this.lname.BaseColor = System.Drawing.Color.White;
            this.lname.BorderColor = System.Drawing.Color.Silver;
            this.lname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.lname.FocusedBaseColor = System.Drawing.Color.White;
            this.lname.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.lname.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.lname.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lname.Location = new System.Drawing.Point(572, 116);
            this.lname.Name = "lname";
            this.lname.PasswordChar = '\0';
            this.lname.Radius = 14;
            this.lname.SelectedText = "";
            this.lname.Size = new System.Drawing.Size(237, 30);
            this.lname.TabIndex = 3;
            this.lname.Text = "gunaTextBox1";
            this.lname.TextOffsetX = 5;
            // 
            // mname
            // 
            this.mname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.mname.BackColor = System.Drawing.Color.Transparent;
            this.mname.BaseColor = System.Drawing.Color.White;
            this.mname.BorderColor = System.Drawing.Color.Silver;
            this.mname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.mname.FocusedBaseColor = System.Drawing.Color.White;
            this.mname.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.mname.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.mname.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.mname.Location = new System.Drawing.Point(152, 198);
            this.mname.Name = "mname";
            this.mname.PasswordChar = '\0';
            this.mname.Radius = 14;
            this.mname.SelectedText = "";
            this.mname.Size = new System.Drawing.Size(237, 30);
            this.mname.TabIndex = 3;
            this.mname.Text = "gunaTextBox1";
            this.mname.TextOffsetX = 5;
            // 
            // warning2
            // 
            this.warning2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.warning2.AutoSize = true;
            this.warning2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warning2.ForeColor = System.Drawing.Color.Red;
            this.warning2.Location = new System.Drawing.Point(569, 149);
            this.warning2.Name = "warning2";
            this.warning2.Size = new System.Drawing.Size(75, 17);
            this.warning2.TabIndex = 2;
            this.warning2.Text = "* warning";
            // 
            // addl1
            // 
            this.addl1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.addl1.BackColor = System.Drawing.Color.Transparent;
            this.addl1.BaseColor = System.Drawing.Color.White;
            this.addl1.BorderColor = System.Drawing.Color.Silver;
            this.addl1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.addl1.FocusedBaseColor = System.Drawing.Color.White;
            this.addl1.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.addl1.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.addl1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.addl1.Location = new System.Drawing.Point(152, 280);
            this.addl1.Name = "addl1";
            this.addl1.PasswordChar = '\0';
            this.addl1.Radius = 14;
            this.addl1.SelectedText = "";
            this.addl1.Size = new System.Drawing.Size(237, 30);
            this.addl1.TabIndex = 3;
            this.addl1.Text = "gunaTextBox1";
            this.addl1.TextOffsetX = 5;
            // 
            // addl2
            // 
            this.addl2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.addl2.BackColor = System.Drawing.Color.Transparent;
            this.addl2.BaseColor = System.Drawing.Color.White;
            this.addl2.BorderColor = System.Drawing.Color.Silver;
            this.addl2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.addl2.FocusedBaseColor = System.Drawing.Color.White;
            this.addl2.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.addl2.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.addl2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.addl2.Location = new System.Drawing.Point(152, 316);
            this.addl2.Name = "addl2";
            this.addl2.PasswordChar = '\0';
            this.addl2.Radius = 14;
            this.addl2.SelectedText = "";
            this.addl2.Size = new System.Drawing.Size(237, 30);
            this.addl2.TabIndex = 3;
            this.addl2.Text = "gunaTextBox1";
            this.addl2.TextOffsetX = 5;
            // 
            // addl3
            // 
            this.addl3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.addl3.BackColor = System.Drawing.Color.Transparent;
            this.addl3.BaseColor = System.Drawing.Color.White;
            this.addl3.BorderColor = System.Drawing.Color.Silver;
            this.addl3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.addl3.FocusedBaseColor = System.Drawing.Color.White;
            this.addl3.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.addl3.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.addl3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.addl3.Location = new System.Drawing.Point(152, 352);
            this.addl3.Name = "addl3";
            this.addl3.PasswordChar = '\0';
            this.addl3.Radius = 14;
            this.addl3.SelectedText = "";
            this.addl3.Size = new System.Drawing.Size(237, 30);
            this.addl3.TabIndex = 3;
            this.addl3.Text = "gunaTextBox1";
            this.addl3.TextOffsetX = 5;
            // 
            // warning3
            // 
            this.warning3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.warning3.AutoSize = true;
            this.warning3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warning3.ForeColor = System.Drawing.Color.Red;
            this.warning3.Location = new System.Drawing.Point(149, 385);
            this.warning3.Name = "warning3";
            this.warning3.Size = new System.Drawing.Size(75, 17);
            this.warning3.TabIndex = 2;
            this.warning3.Text = "* warning";
            // 
            // gunaButton4
            // 
            this.gunaButton4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.gunaButton4.AnimationHoverSpeed = 0.07F;
            this.gunaButton4.AnimationSpeed = 0.03F;
            this.gunaButton4.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton4.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaButton4.BorderColor = System.Drawing.Color.Black;
            this.gunaButton4.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton4.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton4.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.gunaButton4.ForeColor = System.Drawing.Color.White;
            this.gunaButton4.Image = null;
            this.gunaButton4.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton4.Location = new System.Drawing.Point(130, 468);
            this.gunaButton4.Name = "gunaButton4";
            this.gunaButton4.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton4.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton4.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton4.OnHoverImage = null;
            this.gunaButton4.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton4.Radius = 20;
            this.gunaButton4.Size = new System.Drawing.Size(201, 42);
            this.gunaButton4.TabIndex = 1;
            this.gunaButton4.Text = "Change Password";
            this.gunaButton4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton4.Click += new System.EventHandler(this.gunaButton4_Click);
            // 
            // warning6
            // 
            this.warning6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.warning6.AutoSize = true;
            this.warning6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warning6.ForeColor = System.Drawing.Color.Red;
            this.warning6.Location = new System.Drawing.Point(569, 395);
            this.warning6.Name = "warning6";
            this.warning6.Size = new System.Drawing.Size(75, 17);
            this.warning6.TabIndex = 2;
            this.warning6.Text = "* warning";
            // 
            // email
            // 
            this.email.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.email.BackColor = System.Drawing.Color.Transparent;
            this.email.BaseColor = System.Drawing.Color.White;
            this.email.BorderColor = System.Drawing.Color.Silver;
            this.email.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.email.FocusedBaseColor = System.Drawing.Color.White;
            this.email.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.email.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.email.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.email.Location = new System.Drawing.Point(572, 362);
            this.email.Name = "email";
            this.email.PasswordChar = '\0';
            this.email.Radius = 14;
            this.email.SelectedText = "";
            this.email.Size = new System.Drawing.Size(237, 30);
            this.email.TabIndex = 3;
            this.email.Text = "gunaTextBox1";
            this.email.TextOffsetX = 5;
            // 
            // dob
            // 
            this.dob.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dob.BackColor = System.Drawing.Color.Transparent;
            this.dob.BaseColor = System.Drawing.Color.White;
            this.dob.BorderColor = System.Drawing.Color.Silver;
            this.dob.CustomFormat = null;
            this.dob.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dob.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.dob.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dob.ForeColor = System.Drawing.Color.Black;
            this.dob.Location = new System.Drawing.Point(572, 280);
            this.dob.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dob.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dob.Name = "dob";
            this.dob.OnHoverBaseColor = System.Drawing.Color.White;
            this.dob.OnHoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.dob.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.dob.OnPressedColor = System.Drawing.Color.Black;
            this.dob.Radius = 14;
            this.dob.Size = new System.Drawing.Size(223, 30);
            this.dob.TabIndex = 5;
            this.dob.Text = "04 February 2021";
            this.dob.Value = new System.DateTime(2021, 2, 4, 20, 5, 19, 264);
            // 
            // warning5
            // 
            this.warning5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.warning5.AutoSize = true;
            this.warning5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warning5.ForeColor = System.Drawing.Color.Red;
            this.warning5.Location = new System.Drawing.Point(569, 313);
            this.warning5.Name = "warning5";
            this.warning5.Size = new System.Drawing.Size(75, 17);
            this.warning5.TabIndex = 2;
            this.warning5.Text = "* warning";
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(148, 32);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(256, 24);
            this.label15.TabIndex = 2;
            this.label15.Text = "First Name and Last Name";
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(410, 32);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(17, 24);
            this.label16.TabIndex = 2;
            this.label16.Text = "-";
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(433, 32);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(168, 24);
            this.label17.TabIndex = 2;
            this.label17.Text = "NIC of the Admin";
            // 
            // AdminProfileEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1068, 522);
            this.Controls.Add(this.dob);
            this.Controls.Add(this.mname);
            this.Controls.Add(this.lname);
            this.Controls.Add(this.addl3);
            this.Controls.Add(this.addl2);
            this.Controls.Add(this.addl1);
            this.Controls.Add(this.email);
            this.Controls.Add(this.fname);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.warning3);
            this.Controls.Add(this.warning5);
            this.Controls.Add(this.warning6);
            this.Controls.Add(this.warning2);
            this.Controls.Add(this.warning1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gunaButton4);
            this.Controls.Add(this.gunaButton3);
            this.Controls.Add(this.gunaButton1);
            this.Controls.Add(this.gunaVSeparator1);
            this.MinimumSize = new System.Drawing.Size(1084, 561);
            this.Name = "AdminProfileEdit";
            this.Text = " ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI.WinForms.GunaVSeparator gunaVSeparator1;
        private Guna.UI.WinForms.GunaButton gunaButton1;
        private Guna.UI.WinForms.GunaButton gunaButton3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label warning1;
        private Guna.UI.WinForms.GunaTextBox fname;
        private Guna.UI.WinForms.GunaTextBox lname;
        private Guna.UI.WinForms.GunaTextBox mname;
        private System.Windows.Forms.Label warning2;
        private Guna.UI.WinForms.GunaTextBox addl1;
        private Guna.UI.WinForms.GunaTextBox addl2;
        private Guna.UI.WinForms.GunaTextBox addl3;
        private System.Windows.Forms.Label warning3;
        private Guna.UI.WinForms.GunaButton gunaButton4;
        private System.Windows.Forms.Label warning6;
        private Guna.UI.WinForms.GunaTextBox email;
        private Guna.UI.WinForms.GunaDateTimePicker dob;
        private System.Windows.Forms.Label warning5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
    }
}