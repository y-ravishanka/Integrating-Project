﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AdminView
{
    public partial class AdminDoctor : Form
    {
        SQLClass sql = new SQLClass();
        Message msg = new Message();

        private int i = 0, j = 0;
        private Form activeForm = null;
        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-1G3ODQ5;Initial Catalog=ayukarma;Integrated Security=True");

        public AdminDoctor()
        {
            InitializeComponent();
            clickDatabase();
        }

        #region Panel Customize Section
        private void openFroms(Form childForm)
        {
            if (activeForm != null)
            {
                activeForm.Close(); // clear-up the varible to store childForm
            }
            activeForm = childForm; // save childForm in activeForm varible
            childForm.TopLevel = false; // stop childForm from behaving like a controler
            childForm.FormBorderStyle = FormBorderStyle.None; // remove childForm borders
            childForm.Dock = DockStyle.Fill; // make childForm fill the entire space
            panelBase.Controls.Add(childForm);
            panelBase.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }
        #endregion

        #region Function Section
        private void butColor(Button bt)
        {
            Button[] but = { but1, but2, but3, but4 };
            Panel[] pan = { pan1, pan2, pan3, pan4 };
            for (i = 0; i < but.Length; ++i)
            {
                pan[i].BackColor = Color.Gray;
                but[i].BackColor = Color.White;
                if (bt == but[i])
                {
                    pan[i].BackColor = Color.White;
                }
            }
        }

        private void clear()
        {
            warning.Text = null;
            panelSearch.Visible = false;
        }

        private void search()
        {
            clear();
            string tmp = txt.Text;
            if(tmp == "" || tmp == null)
            {
                warning.Text = "* Enter a Doctor Name";
            }
            else
            {
                string[] s = sql.getDoctorDetails(tmp);
                if(int.Parse(s[0]) == 0)
                {
                    warning.Text = "* Invalid Doctor Name";
                }
                else
                {
                    lab1.Text = s[1];
                    lab2.Text = s[2];
                    lab3.Text = s[3];
                    lab4.Text = s[4];
                    lab5.Text = s[5];
                    lab6.Text = s[6];
                    lab7.Text = s[7];
                    lab8.Text = s[8];
                    panelSearch.Visible = true;
                }
            }
        }

        private void clickDatabase()
        {
            clear();
            panelSearch.Visible = false;
            butColor(but1);
            loadData();
            if(activeForm != null)
            {
                activeForm.Close();
            }

            panel3.Visible = true;
            panel2.Visible = true;
        }

        private void clickAdd()
        {
            butColor(but2);
            openFroms(new AdminDoctorAdd());
            panel3.Visible = false;
            panel2.Visible = false;
        }
        #endregion

        #region Load Data Section
        private void loadData()
        {
            string table = "doctor";
            string que = "select * from doctor";

            try
            {
                SqlDataAdapter dta = new SqlDataAdapter(que, con);
                DataSet ds = new DataSet();
                dta.Fill(ds, table);
                dataView.DataSource = ds;
                dataView.DataMember = table;
                table = null;
            }
            catch (Exception e)
            {
                string s1 = Convert.ToString(e);
                msg.invalid_data(s1);
            }
            finally
            {
                con.Close();
            }
        }
        #endregion

        private void but2_Click(object sender, EventArgs e)
        {
            clickAdd();
        }

        private void but1_Click(object sender, EventArgs e)
        {
            clickDatabase();
        }

        private void but3_Click(object sender, EventArgs e)
        {
            butColor(but3);
            openFroms(new AdminDoctorUpdate());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            search();
        }
    }
}
