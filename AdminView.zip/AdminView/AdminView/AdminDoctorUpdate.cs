﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdminView
{
    public partial class AdminDoctorUpdate : Form
    {
        public AdminDoctorUpdate()
        {
            InitializeComponent();
            setTxt1();
        }

        private void setTxt()
        {
            txt2.Multiline = true;
        }

        private void setTxt1()
        {
            txt2.Multiline = false;
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            setTxt();
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            setTxt1();
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            if(combo.Text == "Description")
            {
                setTxt();
            }
            else
            {
                setTxt1();
            }
        }
    }
}
