﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AdminView
{
    public partial class AdminDeleteUser : Form
    {
        Message msg = new Message();
        Calculations cal = new Calculations();
        SQLClass sql = new SQLClass();

        private int i = 0, j = 0;
        private int tmp0 = 0;
        private Form activeForm = null;
        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-1G3ODQ5;Initial Catalog=ayukarma;Integrated Security=True");

        public AdminDeleteUser()
        {
            InitializeComponent();
            butColorNull();
            clickUser();
            clearFields();
        }

        #region Panel Customize Section
        private void openFroms(Form childForm)
        {
            if (activeForm != null)
            {
                activeForm.Close(); // clear-up the varible to store childForm
            }
            activeForm = childForm; // save childForm in activeForm varible
            childForm.TopLevel = false; // stop childForm from behaving like a controler
            childForm.FormBorderStyle = FormBorderStyle.None; // remove childForm borders
            childForm.Dock = DockStyle.Fill; // make childForm fill the entire space
            panelBase.Controls.Add(childForm);
            panelBase.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }
        #endregion

        #region Color Customize Section
        private void butColorNull()
        {
            Panel[] pan1 = { panelUser, panelDeleted, panelBlacklist, /*panelReport,*/ panelEmail };
            Button[] but1 = { butUser, butDeleted, butBlacklist, /*butReport,*/ butEmail };
            for (i = 0; i < pan1.Length; ++i)
            {
                pan1[i].BackColor = Color.Gray;
                but1[i].BackColor = Color.White;
            }
        }

        private void butColor(Button but)
        {
            butColorNull();
            Panel[] pan1 = { panelUser, panelDeleted, panelBlacklist, /*panelReport,*/ panelEmail };
            Button[] but1 = { butUser, butDeleted, butBlacklist, /*butReport,*/ butEmail };
            for (i = 0; i < but1.Length; ++i)
            {
                if(but == but1[i])
                {
                    //pan1[i].BackColor = Color.FromArgb(100, 88, 255);
                    pan1[i].BackColor = Color.White;
                }
            }
        }
        #endregion

        #region Function Section
        private void closeForm()
        {
            if(activeForm != null)
            { activeForm.Close(); }
        }

        private void clickDeleteUser()
        {
            butColor(butDeleted);
            closeForm();
            loadData("deleted");
        }

        private void clickBlackListUser()
        {
            butColor(butBlacklist);
            closeForm();
            loadData("black");
        }

        private void clickUser()
        {
            butColor(butUser);
            closeForm();
            loadData("user");
        }
        /*
        private void clickReport()
        {
            butColor(butReport);
            openFroms(new AdminDeleteUser2());
        }
        */
        private void clickEmail()
        {
            butColor(butEmail);
            openFroms(new AdminSentEmail());
        }

        private void clearFields()
        {
            warning.Text = null;
            fname.Text = "First Name";
            mname.Text = "Middle Name";
            lname.Text = "Last Name";
            al1.Text = "Address Line 1";
            al2.Text = "Address Line 2";
            al3.Text = "Address Line 3";
            gender.Text = "Gender";
            tele.Text = "Telephone";
            email.Text = "Email";
            nic.Text = "NIC No";
            name.Text = "User Name";
            userid.Text = "User ID";
        }

        private void setVaribles(string[] s)
        {
            fname.Text = s[2];
            mname.Text = s[3];
            lname.Text = s[4];
            al1.Text = s[5];
            al2.Text = s[6];
            al3.Text = s[7];
            gender.Text = s[8];
            tele.Text = s[9];
            email.Text = s[10];
            nic.Text = s[1];
            name.Text = s[2] + " " + s[4];
            userid.Text = s[11];
        }

        private void deleteUser()
        {
            if(tmp0 == 1)
            {
                int t = sql.deleteUser(1, txtsreach.Text);
                if(t==1)
                {
                    msg.succes_deleteUser(txtsreach.Text);
                }
                else
                {
                    msg.invalid_deleteUser(txtsreach.Text);
                }
            }
            else if(tmp0 == 2)
            {
                int t = sql.deleteUser(2, txtsreach.Text);
                if (t == 1)
                {
                    msg.succes_deleteUser(txtsreach.Text);
                }
                else
                {
                    msg.invalid_deleteUser(txtsreach.Text);
                }
            }
        }
        #endregion

        #region Load Data Section
        private void loadData(string s)
        {
            string table = null;
            string que = null;

            if(s == "user")
            {
                table = "user";
                que = "select userid as User_ID,nicno as NIC,fname as First_Name,mname as Middle_Name,lname as Last_Name,uadline1 as Address_Line_01,uadline2 as Address_Line_02,uadline3 as Address_Line_03,gender,telephone,email from user";
            }
            else if(s == "deleted")
            {
                table = "userhistory";
                que = "select select userid as User_ID,nicno as NIC,fname as First_Name,mname as Middle_Name,lname as Last_Name,uadline1 as Address_Line_01,uadline2 as Address_Line_02,uadline3 as Address_Line_03,gender,telephone,email from userhistory";
            }
            else if(s == "black")
            {
                table = "userhistory";
                que = "select select userid as User_ID,nicno as NIC,fname as First_Name,mname as Middle_Name,lname as Last_Name,uadline1 as Address_Line_01,uadline2 as Address_Line_02,uadline3 as Address_Line_03,gender,telephone,email from userhistory";
            }
            try
            {
                SqlDataAdapter dta = new SqlDataAdapter(que, con);
                DataSet ds = new DataSet();
                dta.Fill(ds, table);
                dataView.DataSource = ds;
                dataView.DataMember = table;
                table = null;
            }
            catch (Exception e)
            {
                string s1 = Convert.ToString(e);
                msg.invalid_data(s1);
            }
            finally
            {
                con.Close();
            }
        }

        private void loadUserData(string id)
        {
            tmp0 = 0;
            clearFields();
            char[] s = id.ToCharArray();
            int tmp = (s.Length - 1);
            if(s[s.Length-1] == 'v')
            {
                bool b = cal.checkNIC(id);
                if(b == true)
                {
                    string[] data = sql.getUserData(1, id);
                    if(int.Parse(data[0]) == 1)
                    {
                        setVaribles(data);
                        tmp0 = 1;
                    }
                    else
                    {
                        warning.Text = "* invalid NIC";
                    }
                }
                if(b == false)
                {
                    warning.Text = "* please enter a valid NIC";
                }
            }
            else
            {
                int t1 = 0;
                try 
                {
                    int t = int.Parse(id);
                    t = 1;
                }
                catch (Exception e)
                {
                    t1 = 0;
                }
                if(t1 == 1)
                {
                    string[] data = sql.getUserData(2, id);
                    if (int.Parse(data[0]) == 1)
                    {
                        setVaribles(data);
                        tmp0 = 2;
                    }
                    else
                    {
                        warning.Text = "* invalid user ID";
                    }
                }
                else if(t1 == 0)
                {
                    warning.Text = "* please enter a valid user ID";
                }
            }
        }
        #endregion

        private void butUser_Click(object sender, EventArgs e)
        {
            clickUser();
        }

        private void butDeleted_Click(object sender, EventArgs e)
        {
            clickDeleteUser();
        }
        /*
        private void butReport_Click(object sender, EventArgs e)
        {
            clickReport();
        }*/

        private void butEmail_Click(object sender, EventArgs e)
        {
            clickEmail();
        }

        private void butSearch_Click(object sender, EventArgs e)
        {
            loadUserData(txtsreach.Text);
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            deleteUser();
        }

        private void butBlacklist_Click(object sender, EventArgs e)
        {
            clickBlackListUser();
        }

    }
}
