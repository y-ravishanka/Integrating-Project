﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AdminView
{
    public partial class AdminDatabase : Form
    {
        private int i = 0, j = 0;
        private String datatype = null;
        private int bs = 0;

        Message msg = new Message();

        private SqlConnection con = new SqlConnection(@"");

        public AdminDatabase(String data)
        {
            InitializeComponent();
            this.datatype = data;
            customizeForm();
            showPanels();
            butColorNull();
        }

        private void customizeForm()
        {
            if(datatype == "buy")
            {
                typeShow.Text = "Buy Data";
            }
            else if(datatype == "sell")
            {
                typeShow.Text = "Sell Data";
            }
            else if (datatype == "user")
            {
                typeShow.Text = "User Data";
                //panelMaterial.Visible = false;
            }
        }

        #region Customize Panels
        private void showPanels()
        {
            panelBuySellData.Visible = false;
            panelUserData.Visible = false;

            if (datatype == "buy")
            {
                panelBuySellData.Visible = true;
                bs = 1;
            }
            else if (datatype == "sell")
            {
                panelBuySellData.Visible = true;
                bs = 0;
            }
            else if (datatype == "user")
            {
                panelUserData.Visible = true;
            }
        }

        private void HideSubmenu()
        {
            panelProdSub.Visible = false;
            panelRawSub.Visible = false;
        }
        #endregion

        #region Color Customize
        private void butColorNull()
        {
            Button[] b1 = { butProd, butRaw, user1, user2, user3, user4 };
            Button[] b2 = { prod1, prod2, prod3, prod4, prod5, prod6, raw1, raw2, raw3, raw4, raw5, raw6 };
            for(i=0; i<b1.Length; ++i)
            {
                b1[i].BackColor = Color.FromArgb(48, 109, 192);
                b1[i].ForeColor = Color.White;
            }
            for(i=0; i<b2.Length; ++i)
            {
                b2[i].BackColor = Color.FromArgb(28, 77, 133);
                b2[i].ForeColor = Color.White;
            }
        }

        private void butColor(Button but)
        {
            butColorNull();
            but.BackColor = Color.White;
            but.ForeColor = Color.Black;
        }
        /*
        private void materialColor(Button but)
        {
            //butMaterial1.BackColor = Color.White;
            //butMaterial2.BackColor = Color.White;
            but.BackColor = Color.FromArgb(48, 109, 192);
        }*/
        #endregion

        #region DataLoad Section
        private void loadTableData(String s, int t)
        {
            String table = null;
            String que = null;

            try
            {
                con.Open();
            }
            catch (Exception e)
            {
                string s1 = Convert.ToString(e);
                msg.invalid_data(s1);
            }
            if (s == "buy")
            {
                if (t == 0)
                {
                    table = "";
                    que = "";
                }
            }
            else if (s == "sell")
            {

            }

            if (table != null)
            {
                try
                {
                    SqlDataAdapter dta = new SqlDataAdapter(que, con);
                    DataSet ds = new DataSet();
                    dta.Fill(ds, table);
                    dataGrid.DataSource = ds;
                    dataGrid.DataMember = table;
                    table = null;
                }
                catch (Exception e)
                {
                    string s1 = Convert.ToString(e);
                    msg.invalid_data(s1);
                }
                finally
                {
                    con.Close();
                }
            }
        }
        #endregion

        private void button1_Click(object sender, EventArgs e)
        {
        }
        /*
        private void butMaterial1_Click(object sender, EventArgs e)
        {
            materialColor(butMaterial1);
        }

        private void butMaterial2_Click(object sender, EventArgs e)
        {
            materialColor(butMaterial2);
        }
        */
        private void butAllData_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
        }

        #region nothing
        private void panelProdMain_MouseClick(object sender, MouseEventArgs e)
        {}
        #endregion

    }
}
