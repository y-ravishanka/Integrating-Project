﻿using System;
using System.Windows.Forms;

namespace AdminView
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(FormArrange.loginPage);

            //Application.Run(new AdminMenu("981311541v"));

            Application.Run(new SuperAdminMenu());

            //Application.Run(new AdminDeleteUser());

            //Application.Run(new SuperAddAdmin());
            //Application.Run(new AdminDeleteUser());
            //Application.Run(new AdminAddEOrder());
            //Application.Run(new AdminReportGeneral());
            //Application.Run(new AdminDoctorUpdate());

            //Application.Run(new Profile2(""));
        }
    }
}
