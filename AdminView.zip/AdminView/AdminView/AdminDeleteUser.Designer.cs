﻿
namespace AdminView
{
    partial class AdminDeleteUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelParent = new System.Windows.Forms.Panel();
            this.panelBase = new System.Windows.Forms.Panel();
            this.dataView = new Guna.UI.WinForms.GunaDataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panelEmail = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.butEmail = new System.Windows.Forms.Button();
            this.panelBlacklist = new System.Windows.Forms.Panel();
            this.butBlacklist = new System.Windows.Forms.Button();
            this.panelDeleted = new System.Windows.Forms.Panel();
            this.butDeleted = new System.Windows.Forms.Button();
            this.panelUser = new System.Windows.Forms.Panel();
            this.butUser = new System.Windows.Forms.Button();
            this.txtsreach = new Guna.UI.WinForms.GunaTextBox();
            this.butSearch = new Guna.UI.WinForms.GunaButton();
            this.name = new System.Windows.Forms.Label();
            this.nic = new System.Windows.Forms.Label();
            this.gunaButton1 = new Guna.UI.WinForms.GunaButton();
            this.label1 = new System.Windows.Forms.Label();
            this.fname = new System.Windows.Forms.Label();
            this.mname = new System.Windows.Forms.Label();
            this.lname = new System.Windows.Forms.Label();
            this.al1 = new System.Windows.Forms.Label();
            this.al2 = new System.Windows.Forms.Label();
            this.al3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.gender = new System.Windows.Forms.Label();
            this.tele = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.gunaButton2 = new Guna.UI.WinForms.GunaButton();
            this.warning = new System.Windows.Forms.Label();
            this.userid = new System.Windows.Forms.Label();
            this.panelParent.SuspendLayout();
            this.panelBase.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataView)).BeginInit();
            this.panel2.SuspendLayout();
            this.panelEmail.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panelBlacklist.SuspendLayout();
            this.panelDeleted.SuspendLayout();
            this.panelUser.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelParent
            // 
            this.panelParent.Controls.Add(this.panelBase);
            this.panelParent.Controls.Add(this.panel2);
            this.panelParent.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelParent.Location = new System.Drawing.Point(0, 236);
            this.panelParent.Name = "panelParent";
            this.panelParent.Size = new System.Drawing.Size(1068, 286);
            this.panelParent.TabIndex = 0;
            // 
            // panelBase
            // 
            this.panelBase.Controls.Add(this.dataView);
            this.panelBase.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBase.Location = new System.Drawing.Point(0, 50);
            this.panelBase.Name = "panelBase";
            this.panelBase.Size = new System.Drawing.Size(1068, 236);
            this.panelBase.TabIndex = 1;
            // 
            // dataView
            // 
            this.dataView.AllowUserToAddRows = false;
            this.dataView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.dataView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataView.BackgroundColor = System.Drawing.Color.White;
            this.dataView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataView.ColumnHeadersHeight = 21;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataView.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataView.EnableHeadersVisualStyles = false;
            this.dataView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dataView.Location = new System.Drawing.Point(0, 0);
            this.dataView.Name = "dataView";
            this.dataView.ReadOnly = true;
            this.dataView.RowHeadersVisible = false;
            this.dataView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataView.Size = new System.Drawing.Size(1068, 236);
            this.dataView.TabIndex = 1;
            this.dataView.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Guna;
            this.dataView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.dataView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dataView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dataView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dataView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dataView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.dataView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dataView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.dataView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dataView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.dataView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dataView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.dataView.ThemeStyle.HeaderStyle.Height = 21;
            this.dataView.ThemeStyle.ReadOnly = true;
            this.dataView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dataView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.dataView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dataView.ThemeStyle.RowsStyle.Height = 22;
            this.dataView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dataView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panelEmail);
            this.panel2.Controls.Add(this.panelBlacklist);
            this.panel2.Controls.Add(this.panelDeleted);
            this.panel2.Controls.Add(this.panelUser);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1068, 50);
            this.panel2.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.Location = new System.Drawing.Point(0, 5);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(308, 45);
            this.panel5.TabIndex = 5;
            // 
            // panelEmail
            // 
            this.panelEmail.Controls.Add(this.panel4);
            this.panelEmail.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelEmail.Location = new System.Drawing.Point(308, 0);
            this.panelEmail.Name = "panelEmail";
            this.panelEmail.Size = new System.Drawing.Size(190, 50);
            this.panelEmail.TabIndex = 4;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.butEmail);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 5);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(190, 45);
            this.panel4.TabIndex = 0;
            // 
            // butEmail
            // 
            this.butEmail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.butEmail.FlatAppearance.BorderSize = 0;
            this.butEmail.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.butEmail.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.butEmail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butEmail.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butEmail.Location = new System.Drawing.Point(0, 0);
            this.butEmail.Name = "butEmail";
            this.butEmail.Size = new System.Drawing.Size(190, 45);
            this.butEmail.TabIndex = 0;
            this.butEmail.Text = "Send an Email";
            this.butEmail.UseVisualStyleBackColor = true;
            this.butEmail.Click += new System.EventHandler(this.butEmail_Click);
            // 
            // panelBlacklist
            // 
            this.panelBlacklist.Controls.Add(this.butBlacklist);
            this.panelBlacklist.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelBlacklist.Location = new System.Drawing.Point(498, 0);
            this.panelBlacklist.Name = "panelBlacklist";
            this.panelBlacklist.Size = new System.Drawing.Size(190, 50);
            this.panelBlacklist.TabIndex = 2;
            // 
            // butBlacklist
            // 
            this.butBlacklist.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.butBlacklist.FlatAppearance.BorderSize = 0;
            this.butBlacklist.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.butBlacklist.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.butBlacklist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butBlacklist.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butBlacklist.Location = new System.Drawing.Point(0, 5);
            this.butBlacklist.Name = "butBlacklist";
            this.butBlacklist.Size = new System.Drawing.Size(190, 45);
            this.butBlacklist.TabIndex = 0;
            this.butBlacklist.Text = "Black List Users";
            this.butBlacklist.UseVisualStyleBackColor = true;
            this.butBlacklist.Click += new System.EventHandler(this.butBlacklist_Click);
            // 
            // panelDeleted
            // 
            this.panelDeleted.Controls.Add(this.butDeleted);
            this.panelDeleted.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelDeleted.Location = new System.Drawing.Point(688, 0);
            this.panelDeleted.Name = "panelDeleted";
            this.panelDeleted.Size = new System.Drawing.Size(190, 50);
            this.panelDeleted.TabIndex = 1;
            // 
            // butDeleted
            // 
            this.butDeleted.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.butDeleted.FlatAppearance.BorderSize = 0;
            this.butDeleted.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.butDeleted.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.butDeleted.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butDeleted.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butDeleted.Location = new System.Drawing.Point(0, 5);
            this.butDeleted.Name = "butDeleted";
            this.butDeleted.Size = new System.Drawing.Size(190, 45);
            this.butDeleted.TabIndex = 0;
            this.butDeleted.Text = "Deleted Users";
            this.butDeleted.UseVisualStyleBackColor = true;
            this.butDeleted.Click += new System.EventHandler(this.butDeleted_Click);
            // 
            // panelUser
            // 
            this.panelUser.Controls.Add(this.butUser);
            this.panelUser.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelUser.Location = new System.Drawing.Point(878, 0);
            this.panelUser.Name = "panelUser";
            this.panelUser.Size = new System.Drawing.Size(190, 50);
            this.panelUser.TabIndex = 0;
            // 
            // butUser
            // 
            this.butUser.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.butUser.FlatAppearance.BorderSize = 0;
            this.butUser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.butUser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.butUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butUser.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butUser.Location = new System.Drawing.Point(0, 5);
            this.butUser.Name = "butUser";
            this.butUser.Size = new System.Drawing.Size(190, 45);
            this.butUser.TabIndex = 0;
            this.butUser.Text = "Users";
            this.butUser.UseVisualStyleBackColor = true;
            this.butUser.Click += new System.EventHandler(this.butUser_Click);
            // 
            // txtsreach
            // 
            this.txtsreach.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtsreach.BackColor = System.Drawing.Color.Transparent;
            this.txtsreach.BaseColor = System.Drawing.Color.White;
            this.txtsreach.BorderColor = System.Drawing.Color.Silver;
            this.txtsreach.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtsreach.FocusedBaseColor = System.Drawing.Color.White;
            this.txtsreach.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtsreach.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtsreach.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtsreach.Location = new System.Drawing.Point(416, 9);
            this.txtsreach.Name = "txtsreach";
            this.txtsreach.PasswordChar = '\0';
            this.txtsreach.SelectedText = "";
            this.txtsreach.Size = new System.Drawing.Size(272, 32);
            this.txtsreach.TabIndex = 1;
            this.txtsreach.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtsreach.TextOffsetX = 10;
            // 
            // butSearch
            // 
            this.butSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.butSearch.AnimationHoverSpeed = 0.07F;
            this.butSearch.AnimationSpeed = 0.03F;
            this.butSearch.BackColor = System.Drawing.Color.Transparent;
            this.butSearch.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.butSearch.BorderColor = System.Drawing.Color.Black;
            this.butSearch.DialogResult = System.Windows.Forms.DialogResult.None;
            this.butSearch.FocusedColor = System.Drawing.Color.Empty;
            this.butSearch.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.butSearch.ForeColor = System.Drawing.Color.White;
            this.butSearch.Image = null;
            this.butSearch.ImageSize = new System.Drawing.Size(20, 20);
            this.butSearch.Location = new System.Drawing.Point(701, 9);
            this.butSearch.Name = "butSearch";
            this.butSearch.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.butSearch.OnHoverBorderColor = System.Drawing.Color.Black;
            this.butSearch.OnHoverForeColor = System.Drawing.Color.White;
            this.butSearch.OnHoverImage = null;
            this.butSearch.OnPressedColor = System.Drawing.Color.Black;
            this.butSearch.Size = new System.Drawing.Size(110, 32);
            this.butSearch.TabIndex = 2;
            this.butSearch.Text = "Search";
            this.butSearch.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
            // 
            // name
            // 
            this.name.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.name.AutoSize = true;
            this.name.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.Location = new System.Drawing.Point(11, 9);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(141, 21);
            this.name.TabIndex = 3;
            this.name.Text = "Users Name Here";
            this.name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nic
            // 
            this.nic.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nic.AutoSize = true;
            this.nic.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nic.Location = new System.Drawing.Point(11, 30);
            this.nic.Name = "nic";
            this.nic.Size = new System.Drawing.Size(73, 21);
            this.nic.TabIndex = 4;
            this.nic.Text = "2546326";
            this.nic.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // gunaButton1
            // 
            this.gunaButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaButton1.AnimationHoverSpeed = 0.07F;
            this.gunaButton1.AnimationSpeed = 0.03F;
            this.gunaButton1.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.gunaButton1.ForeColor = System.Drawing.Color.White;
            this.gunaButton1.Image = null;
            this.gunaButton1.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton1.Location = new System.Drawing.Point(817, 9);
            this.gunaButton1.Name = "gunaButton1";
            this.gunaButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton1.OnHoverImage = null;
            this.gunaButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton1.Size = new System.Drawing.Size(113, 32);
            this.gunaButton1.TabIndex = 5;
            this.gunaButton1.Text = "Delete User";
            this.gunaButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton1.Click += new System.EventHandler(this.gunaButton1_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(11, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 21);
            this.label1.TabIndex = 6;
            this.label1.Text = "Name - ";
            // 
            // fname
            // 
            this.fname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.fname.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fname.Location = new System.Drawing.Point(38, 123);
            this.fname.Name = "fname";
            this.fname.Size = new System.Drawing.Size(235, 23);
            this.fname.TabIndex = 7;
            this.fname.Text = "First Name";
            // 
            // mname
            // 
            this.mname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.mname.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mname.Location = new System.Drawing.Point(38, 146);
            this.mname.Name = "mname";
            this.mname.Size = new System.Drawing.Size(235, 23);
            this.mname.TabIndex = 7;
            this.mname.Text = "Middle Name";
            // 
            // lname
            // 
            this.lname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lname.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lname.Location = new System.Drawing.Point(38, 169);
            this.lname.Name = "lname";
            this.lname.Size = new System.Drawing.Size(235, 23);
            this.lname.TabIndex = 7;
            this.lname.Text = "Last Name";
            // 
            // al1
            // 
            this.al1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.al1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.al1.Location = new System.Drawing.Point(317, 123);
            this.al1.Name = "al1";
            this.al1.Size = new System.Drawing.Size(235, 23);
            this.al1.TabIndex = 7;
            this.al1.Text = "Address Line 1";
            // 
            // al2
            // 
            this.al2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.al2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.al2.Location = new System.Drawing.Point(317, 146);
            this.al2.Name = "al2";
            this.al2.Size = new System.Drawing.Size(235, 23);
            this.al2.TabIndex = 7;
            this.al2.Text = "Address Line 2";
            // 
            // al3
            // 
            this.al3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.al3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.al3.Location = new System.Drawing.Point(317, 169);
            this.al3.Name = "al3";
            this.al3.Size = new System.Drawing.Size(235, 23);
            this.al3.TabIndex = 7;
            this.al3.Text = "Address Line 3";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(269, 91);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(84, 21);
            this.label8.TabIndex = 6;
            this.label8.Text = "Address - ";
            // 
            // gender
            // 
            this.gender.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gender.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gender.Location = new System.Drawing.Point(618, 123);
            this.gender.Name = "gender";
            this.gender.Size = new System.Drawing.Size(121, 23);
            this.gender.TabIndex = 7;
            this.gender.Text = "Gender";
            // 
            // tele
            // 
            this.tele.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tele.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tele.Location = new System.Drawing.Point(821, 123);
            this.tele.Name = "tele";
            this.tele.Size = new System.Drawing.Size(235, 23);
            this.tele.TabIndex = 7;
            this.tele.Text = "Telephone";
            // 
            // email
            // 
            this.email.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.email.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.Location = new System.Drawing.Point(618, 199);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(355, 23);
            this.email.TabIndex = 7;
            this.email.Text = "Email";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(580, 91);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(79, 21);
            this.label12.TabIndex = 6;
            this.label12.Text = "Gender - ";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(762, 91);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(104, 21);
            this.label13.TabIndex = 6;
            this.label13.Text = "Telephone - ";
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(580, 169);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(67, 21);
            this.label14.TabIndex = 6;
            this.label14.Text = "Email - ";
            // 
            // gunaButton2
            // 
            this.gunaButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaButton2.AnimationHoverSpeed = 0.07F;
            this.gunaButton2.AnimationSpeed = 0.03F;
            this.gunaButton2.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaButton2.BorderColor = System.Drawing.Color.Black;
            this.gunaButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton2.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.gunaButton2.ForeColor = System.Drawing.Color.White;
            this.gunaButton2.Image = null;
            this.gunaButton2.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton2.Location = new System.Drawing.Point(936, 9);
            this.gunaButton2.Name = "gunaButton2";
            this.gunaButton2.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton2.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton2.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton2.OnHoverImage = null;
            this.gunaButton2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton2.Size = new System.Drawing.Size(120, 32);
            this.gunaButton2.TabIndex = 5;
            this.gunaButton2.Text = "Blacklist User";
            this.gunaButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // warning
            // 
            this.warning.AutoSize = true;
            this.warning.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warning.ForeColor = System.Drawing.Color.Red;
            this.warning.Location = new System.Drawing.Point(413, 44);
            this.warning.Name = "warning";
            this.warning.Size = new System.Drawing.Size(70, 19);
            this.warning.TabIndex = 8;
            this.warning.Text = "* warning";
            // 
            // userid
            // 
            this.userid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.userid.AutoSize = true;
            this.userid.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userid.Location = new System.Drawing.Point(11, 51);
            this.userid.Name = "userid";
            this.userid.Size = new System.Drawing.Size(73, 21);
            this.userid.TabIndex = 4;
            this.userid.Text = "2546326";
            this.userid.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // AdminDeleteUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1068, 522);
            this.Controls.Add(this.warning);
            this.Controls.Add(this.al3);
            this.Controls.Add(this.lname);
            this.Controls.Add(this.al2);
            this.Controls.Add(this.email);
            this.Controls.Add(this.tele);
            this.Controls.Add(this.gender);
            this.Controls.Add(this.al1);
            this.Controls.Add(this.mname);
            this.Controls.Add(this.fname);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gunaButton2);
            this.Controls.Add(this.gunaButton1);
            this.Controls.Add(this.userid);
            this.Controls.Add(this.nic);
            this.Controls.Add(this.name);
            this.Controls.Add(this.butSearch);
            this.Controls.Add(this.txtsreach);
            this.Controls.Add(this.panelParent);
            this.MinimumSize = new System.Drawing.Size(1084, 561);
            this.Name = "AdminDeleteUser";
            this.Text = "AdminDeleteUser";
            this.panelParent.ResumeLayout(false);
            this.panelBase.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataView)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panelEmail.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panelBlacklist.ResumeLayout(false);
            this.panelDeleted.ResumeLayout(false);
            this.panelUser.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panelUser;
        private System.Windows.Forms.Button butUser;
        private System.Windows.Forms.Panel panelDeleted;
        private System.Windows.Forms.Button butDeleted;
        private System.Windows.Forms.Panel panelBlacklist;
        private System.Windows.Forms.Button butBlacklist;
        private Guna.UI.WinForms.GunaTextBox txtsreach;
        private Guna.UI.WinForms.GunaButton butSearch;
        private System.Windows.Forms.Panel panelParent;
        private Guna.UI.WinForms.GunaDataGridView dataView;
        private System.Windows.Forms.Panel panelBase;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panelEmail;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button butEmail;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label nic;
        private Guna.UI.WinForms.GunaButton gunaButton1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label fname;
        private System.Windows.Forms.Label mname;
        private System.Windows.Forms.Label lname;
        private System.Windows.Forms.Label al1;
        private System.Windows.Forms.Label al2;
        private System.Windows.Forms.Label al3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label gender;
        private System.Windows.Forms.Label tele;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private Guna.UI.WinForms.GunaButton gunaButton2;
        private System.Windows.Forms.Label warning;
        private System.Windows.Forms.Label userid;
    }
}