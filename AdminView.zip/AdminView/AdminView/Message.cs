﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdminView
{
    class Message
    {
        public void invalid_data(string s1)
        {
            DialogResult d;
            d = MessageBox.Show("Invild Entry !!!\nPlease check your Entered Data\n" + s1, "Error !!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            if (d == DialogResult.OK)
            {
            }
        }

        public void succes_que()
        {
            DialogResult d;
            d = MessageBox.Show("Succesful Query", "Succesful", MessageBoxButtons.OK, MessageBoxIcon.Information);
            if (d == DialogResult.OK)
            {
            }
        }

        public void succes_changePassword()
        {
            DialogResult d;
            d = MessageBox.Show("Password change succesfully\nYou can use your new password", "Notification !!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            if (d == DialogResult.OK)
            {
            }
            
        }

        public void invalid_changePassword()
        {
            DialogResult d;
            d = MessageBox.Show("something went wrong !!!\nPassword is not change", "Error !!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            if (d == DialogResult.OK)
            {
            }
        }

        public void succes_deleteUser(string s1)
        {
            DialogResult d;
            d = MessageBox.Show("you have deleted user : " + s1, "Notification !!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            if (d == DialogResult.OK)
            {
            }
        }

        public void invalid_deleteUser(string s1)
        {
            DialogResult d;
            d = MessageBox.Show("something went wrong !!!\nuser : "+s1+" is not deleted", "Error !!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            if (d == DialogResult.OK)
            {
            }

        }
    }
}
