﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdminView
{
    public partial class AdminDoctorAdd : Form
    {
        SQLClass sql = new SQLClass();

        private int i = 0, j = 0;

        public AdminDoctorAdd()
        {
            InitializeComponent();
            clearFields();
        }

        #region Fucntion Section
        private void clearFields()
        {
            tx1.Text = null;
            tx2.Text = null;
            tx3.Text = null;
            tx4.Text = null;
            tx5.Text = null;
            tx6.Text = null;
            tx7.Text = null;
            warning.Text = null;
        }

        private void clear()
        {
            warning.Text = null;
        }

        private void error(int t)
        {
            if(t == 1)
            {
                warning.Text = "* Please Fill All the Columns";
            }
            else if(t == 2)
            {
                warning.Text = "* Invail Data";
            }
        }

        private int check()
        {
            int tmp = 0;
            if(tx1.Text == "" || tx1.Text == null)
            {
                error(1);
            }
            else if (tx2.Text == "" || tx2.Text == null)
            {
                error(1);
            }
            else if (tx3.Text == "" || tx3.Text == null)
            {
                error(1);
            }
            else if (tx4.Text == "" || tx4.Text == null)
            {
                error(1);
            }
            else if (tx5.Text == "" || tx5.Text == null)
            {
                error(1);
            }
            else if (tx6.Text == "" || tx6.Text == null)
            {
                error(1);
            }
            else if (tx7.Text == "" || tx7.Text == null)
            {
                error(1);
            }
            else
            {
                tmp = 1;
            }
            return tmp;
        }

        private void addDoctor()
        {
            clear();
            if (check() == 1)
            {
                int t1 = sql.insertDoctor(tx1.Text, int.Parse(tx2.Text), tx3.Text, tx4.Text, tx5.Text, decimal.Parse(tx6.Text), decimal.Parse(tx7.Text));
                if (t1 == 1)
                {
                    warning.Text = "Record has added to the Database";
                }
                else if (t1 == 0)
                {
                    error(2);
                }
            }
        }
        #endregion

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            addDoctor();
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            clearFields();
        }
    }
}
