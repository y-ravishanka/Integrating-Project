﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdminView
{
    public partial class LoginPage : Form
    {
        SQLClass sql = new SQLClass();
        EncryptClass ent = new EncryptClass();

        private string nic = null;

        public LoginPage()
        {
            InitializeComponent();
            customizePictueBox();
            customizeForm();
        }

        #region Control Box Functions
        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        #endregion

        private void customizeForm()
        {
            uname.Text = "User Name";
            pword.Text = "Password";
            uname.ForeColor = Color.Gray;
            pword.PasswordChar = '\0';
            pword.ForeColor = Color.Gray;
            warning.Text = null;
        }

        #region Customize User & Password Boxs
        private void uname_Enter(object sender, EventArgs e)
        {
            if (uname.Text == "User Name")
            {
                uname.Text = "";
                uname.ForeColor = Color.Black;
            }
        }

        private void uname_Leave(object sender, EventArgs e)
        {
            if (uname.Text == "")
            {
                uname.Text = "User Name";
                uname.ForeColor = Color.Gray;
            }
        }

        private void pword_Enter(object sender, EventArgs e)
        {
            if (pword.Text == "Password")
            {
                pword.Text = "";
                pword.ForeColor = Color.Black;
                pword.PasswordChar = '*';
            }
        }

        private void pword_Leave(object sender, EventArgs e)
        {
            if (pword.Text == "")
            {
                pword.Text = "Password";
                pword.PasswordChar = '\0';
                pword.ForeColor = Color.Gray;
            }
        }
        #endregion

        private void customizePictueBox()
        {
            picLogo.BackColor = Color.Transparent;
            picLogo.Parent = picMain;
            picLogo.Location = new Point(30, 210);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            customizeForm();
            ResetPassword ob1 = new ResetPassword();
            ob1.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            String u = uname.Text;
            String p = pword.Text;
            int t = LogIn(u, p);
            if(t == 1)
            {
                AdminMenu ob2 = new AdminMenu(u);
                customizeForm();
                ob2.Show();
                this.Hide();
            }
            else if(t == 2)
            {
                SuperAdminMenu ob4 = new SuperAdminMenu();
                customizeForm();
                ob4.Show();
                this.Hide();
            }
            else if (t == 3)
            {
                Profile2 ob4 = new Profile2(u);
                customizeForm();
                ob4.Show();
                this.Hide();
            }
        }

        private int LogIn(String s1, String s2)
        {
            int t = 0;
            if((s1 == null) || (s1 == "") || (s1 == "User Name"))
            {
                warning.Text = "* Please Enter your Username";
                t = 0;
            }
            else if(sql.checkAdminNew(s1) == 0)
            {
                t = 3;
            }
            else if((s2 == null) || (s2 == "") || (s2 == "Password"))
            {
                warning.Text = "* Please Enter your Password";
                t = 0;
            }
            else
            {
                string[] tmp = sql.check_Login(s1);
                if(int.Parse(tmp[0]) == 0)
                {
                    warning.Text = "* Invaild Username, Please your Username";
                    t = 0;
                }
                else if(ent.Decrypt(s2,s1) != s2)
                {
                    warning.Text = "* Invaild Password, Please your Password";
                    t = 0;
                }
                else
                {
                    t = sql.getPosition(s1);
                }
            }
            return t;
        }
    }
}
