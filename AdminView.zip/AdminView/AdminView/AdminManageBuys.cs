﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdminView
{
    public partial class AdminManageBuys : Form
    {
        SQLClass sql = new SQLClass();

        private int i = 0, j = 0;
        private int n = 0;

        public AdminManageBuys()
        {
            InitializeComponent();
        }

        private void sidNav(string s)
        {
            int[] t1 = sql.getSellid();
            if(s == "n")
            {
                if(n != (t1.Length - 1))
                {
                    n++;
                    loadSellData(t1[n]);
                }
                else
                {
                    n = 0;
                    loadSellData(t1[n]);
                }
            }
            if(s == "b")
            {
                if (n != 0)
                {
                    n -= 1;
                    loadSellData(t1[n]);
                }
                else
                {
                    n = (t1.Length - 1);
                    loadSellData(t1[n]);
                }
            }
        }

        private void loadSellData(int t)
        {
            string[] s = sql.getSellData(t);
            l1.Text = t.ToString();
            l2.Text = s[0];
            l3.Text = s[1];
            l4.Text = s[2];
            l5.Text = s[3];
            l6.Text = s[4];
            l7.Text = s[5];
            l8.Text = s[6];
            l9.Text = s[7];
            pic1.Tag = s[8];
            pic2.Tag = s[9];
            pic3.Tag = s[10];
            pic4.Tag = s[11];
            pic5.Tag = s[12];
        }

        private void setData()
        {
            string s = l4.Text;
            string[] c1 = { "balm", "creem and gel", "tonic and oil", "powder", "tablets", "guli or pill" };
            string[] c2 = { "herbs", "leaves", "wood type", "flowers", "fruit type", "oils" };

            for(i=0;i<c1.Length;++i)
            {
                if(s == c1[i])
                {
                    int t = sql.setProducts(l3.Text, l3.Text, float.Parse(l5.Text), pic1.Tag.ToString(), l4.Text, l4.Text);
                }
                else if(s == c2[i])
                {
                    int t = sql.setMaterial(l3.Text, l3.Text, float.Parse(l5.Text), pic1.Tag.ToString(), l4.Text, l4.Text);
                }
            }
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            sidNav("b");
        }

        private void gunaButton3_Click(object sender, EventArgs e)
        {
            setData();
        }

        private void gunaButton4_Click(object sender, EventArgs e)
        {
            int t = sql.deleteSell(int.Parse(l1.Text));
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            sidNav("n");
        }

    }
}
