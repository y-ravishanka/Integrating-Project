﻿
select * from ADMINS
select * from admindetails

INSERT INTO ADMINS ( AdminID, FName,  MName,  LName,  NICNo, Dob, AADLine1, AADLine2,  AADLine3, Email)
VALUES ('AID12346',	'rajitha',	'vishwajith',	'abeykoon',	'981311541v','1998-05-01','acb','abd','asd','hello@gamil.com');

INSERT INTO admindetails ( NICNo,  Password,  Position,  Temp)
VALUES ('981311541v','1234'	,'admin','1');

INSERT INTO Doctor(Docname, Phone, Email, Descrip, ImageName, Lat, Lng) 
VALUES
('D Tennakoon', 0451234567, 'tennakoon@mail.com', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas pretium non nisi in rutrum.', 'maledoc.jpg', 6.7056, 80.3847),
('Y Lokukankanamge', 0341234567, 'kankanamge@mail.com', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas pretium non nisi in rutrum.', 'maledoc.jpg', 6.5854, 79.9607),
('D Samaranayaka', 0371234567, 'samaranayaka@mail.com', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas pretium non nisi in rutrum.', 'femaledoc.jpg', 7.4818, 80.3609),
('R Arsakulasooriya', 0452234567, 'arsakulasooriya@mail.com', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas pretium non nisi in rutrum.', 'maledoc.jpg', 6.6111, 80.4237),
('A Yasuru', 0111234567, 'yasuru@mail.com', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas pretium non nisi in rutrum.', 'maledoc.jpg', 6.8517, 80.0327),
('R Abeykoon', 0251234567, 'abeykoon@mail.com', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas pretium non nisi in rutrum.', 'maledoc.jpg', 8.3114, 80.4037),
('S Welivita', 0112234567, 'welivita@mail.com', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas pretium non nisi in rutrum.', 'femaledoc.jpg', 6.8433, 80.0032),
('R Dilshan', 0521234567, 'dilshan@mail.com', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas pretium non nisi in rutrum.', 'maledoc.jpg', 6.9497, 80.7891),
('R Jayathilaka', 0453234567, 'jayathilaka@mail.com', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas pretium non nisi in rutrum.', 'maledoc.jpg', 6.8218, 80.3615);


INSERT INTO Products ( NAME, Description, Price, ImageName, Category, TAGS)
VALUES ('aaaaa','aaaaaa','1232','aaaaa','harbs','harbs');

INSERT INTO RawMaterials ( NAME, Description, Price, ImageName, Category, TAGS)
VALUES ( 'acaaa','aaaaaaa','1236','aaaaa','harbs','harbs');



